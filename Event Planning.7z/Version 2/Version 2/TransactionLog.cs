﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Version_2
{
    class TransactionLog
    {
        private string whatAdd = "??";
        private string recordID1 = " ";
        private string recordID2 = " ";
        private DateTime DateAndTime;


        public string Whatadded
        {

            get { return whatAdd; }

            set
            {
                whatAdd = value;
            }
        }

        public string RecordedID1
        {

            get { return recordID1; }

            set
            {
                recordID1 = value;
            }
        }

        public string RecordedID2
        {

            get { return recordID2; }

            set
            {
                recordID2 = value;
            }
        }

        public DateTime DAT
        {

            get { return DateAndTime; }

            set
            {
                DateAndTime = value;
            }
        }
    }
}
