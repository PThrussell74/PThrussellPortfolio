﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Version_2
{
    class EveStorage
    {
        private string name = "?";
        private string dateofevent = "??/??/????";
        private int totalnooftickets = 0;
        private double priceticket = 0;
        private int idofevent;
        private DateTime doe;

        public int EID
        {

            get { return idofevent; }

            set
            {
                idofevent = value;
            }
        }

        public DateTime DATE
        {

            get { return doe; }

            set
            {
                doe = value;
            }
        }
        public string EName
        {

            get { return name; }

            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                {
                    name = value;
                }
            }
        }

        public string EDate
        {

            get { return dateofevent; }

            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                {
                    dateofevent = value;
                }
            }
        }
        public int TTickets
        {

            get { return totalnooftickets; }

            set
            {
                if (value <= 0)
                {
                    
                }
                else
                {
                    totalnooftickets = value;
                }
            }
        }
        public double TPrice
        {

            get { return priceticket; }

            set
            {
                if (value <= 0)
                {

                }
                else
                {
                    priceticket = value;
                }
            }
        }
    }
}
