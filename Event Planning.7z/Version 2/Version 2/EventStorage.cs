﻿using System;

namespace Version_2
{
    class EventStorage
    {
        private string EName = "??";


        public string EName
        {
            get { return eventName; }

            set
            {
                if (!String.IsNullOrWhiteSpace(value)
                    && value.Length < 41)
                {
                    EName = value;
                }
            }
        }
    }
}