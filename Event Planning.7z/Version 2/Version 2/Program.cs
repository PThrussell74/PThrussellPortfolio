﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Version_2
{
    class Program
    {
        //Setup for arrays and values
        private static ArrayList events = new ArrayList();
        private static ArrayList bookings = new ArrayList();
        private static ArrayList transactions = new ArrayList();
        private static int eventID = 1;
        private static int bookingID = 1;


        //Main code
        static void Main(string[] args)
        {
            int choice = 0;
            
            while (choice != -1)
            {
                showChoices();
                bool legalInput;
                do
                {
                    try
                    {
                        choice = Convert.ToInt32(Console.ReadLine()); ;
                        if (choice >= 1 && choice <= 7)
                        {
                            legalInput = true;
                        }
                        else if (choice == -1)
                        {
                            legalInput = true;
                        }
                        else
                        {
                            legalInput = false;
                            Console.WriteLine("- Sorry this is not a valid input!");
                        }

                    }
                    catch (System.FormatException)
                    {
                        legalInput = false;
                        Console.WriteLine("- Sorry this is not a valid input!");
                    }
                }
                while (!legalInput);
                redirector(choice);
            }

        }


        //This shows the choices, checks for a response (and error checks) and sends it to the redirector
        private static void showChoices()
        {
            Console.WriteLine("1: Add Event");
            Console.WriteLine("2: Update Event");
            Console.WriteLine("3: Delete Event");
            Console.WriteLine("---");
            Console.WriteLine("4: Book Tickets");
            Console.WriteLine("5: Cancel Booking");
            Console.WriteLine("---");
            Console.WriteLine("6: Display a list of events / bookings");
            Console.WriteLine("7: Display the transaction log");
            Console.WriteLine("---");
            Console.Write("Enter an option (1-7, -1 to exit): > ");
        }
        //This recieves the input from showChoices() and activates the specific menu choice
        private static void redirector(int choice)
        {

            const int ADDEVENT = 1;
            const int UPDATEEVENT = 2;
            const int DELETEEVENT = 3;
            const int BOOKTICKETS = 4;
            const int CANCELBOOKING = 5;
            const int LISTEVENTS = 6;
            const int TRANSACTIONLOG = 7;
            switch (choice)
            {
                case ADDEVENT:
                    addAnEvent();
                    break;
                case UPDATEEVENT:
                    updateAnEvent();
                    break;
                case DELETEEVENT:
                    deleteEvent();
                    break;
                case BOOKTICKETS:
                    bookTickets();
                    break;
                case CANCELBOOKING:
                    deleteBooking();
                    break;
                case LISTEVENTS:
                    viewEvents();
                    break;
                case TRANSACTIONLOG:
                    viewTransactionLog();
                    break;
            }

        }


        //Submitters, these send data to the corresponding array lists
        private static void submitEvent(string eventName, String eventDate, int totalTickets, double ticketPrice, DateTime dateModified, int savedID)
        {
            int eventIDRead = savedID;
            if (savedID == 0)
            {
                eventIDRead = eventID++;
            }

            EveStorage details =
                 new EveStorage
                 {
                    EID = eventIDRead,
                    EName = eventName,
                    EDate = eventDate,
                    TTickets = totalTickets,
                    TPrice = ticketPrice,
                    DATE = dateModified
                };
            events.Add(details);
        }
        private static void submitBooking(string customerName, String address, int evID, int tickTotal)
        {
            BookStorage details =
                 new BookStorage
                 {
                     BID = bookingID++,
                     BName = customerName,
                     Address = address,
                     EventID = evID,
                     TTickets = tickTotal,
                 };
            bookings.Add(details);
        }
        private static void writeToLog(string action, string val1, string val2, DateTime val3)
        {

            if (action.Equals("Booking Tickets"))
            {
                val1 = ("Booking ID: "+(bookingID-1).ToString());
            }
            if (action.Equals("Adding Event"))
            {
                val1 = ("Event ID: " + (eventID - 1).ToString());
            }
            TransactionLog details =
                 new TransactionLog
                 {
                     Whatadded = action,
                     RecordedID1 = val1,
                     RecordedID2 = val2,
                     DAT = val3,
                 };
            transactions.Add(details);
        }
        

        //Menu choices, these recieve data inputs and do certain specifified actions
        private static void addAnEvent()
        {


            String eventName = inputString("What is the name of the event? >");
            String eventDate = inputDate();
            int totalTickets = inputInt("What is the total ticket number?: >");
            double ticketPrice = inputDouble("What is the price of each ticket?: >");
            DateTime dateModified = DateTime.Now;
            int savedID = 0;
            submitEvent(eventName, eventDate, totalTickets, ticketPrice, dateModified, savedID);
            string action = "Adding Event";
            string val1 = "";
            string val2 = ("Event name: " + eventName + " Event Date: " + eventDate + " Total Tickets: " + totalTickets+ " Ticket Price: "+ ticketPrice);
            DateTime val3 = DateTime.Now;
            writeToLog(action, val1, val2, val3);

        }
        private static void updateAnEvent()
        {

            int ID = inputInt("What is the booking ID you wish to change?: >");

            Boolean found = false;

            for (int i = 0; i < events.Count; i++)
            {
                EveStorage details = (EveStorage)events[i];
                if (details.EID == ID || found)
                {
                    found = true;
                    events.Remove(details);
                    String eventName = inputString("What is the name of the event? >");
                    String eventDate = inputDate();
                    int totalTickets = inputInt("What is the total ticket number?: >");
                    double ticketPrice = inputDouble("What is the price of each ticket?: >");
                    DateTime dateModified = DateTime.Now;
                    int savedID = ID;
                    submitEvent(eventName, eventDate, totalTickets, ticketPrice, dateModified, savedID);
                    string action = "Updating Event";
                    string val1 = ("Event ID: "+ID);
                    string val2 = ("Event name: " + eventName + " Event Date: " + eventDate + " Total Tickets: " + totalTickets + " Ticket Price: " + ticketPrice);
                    DateTime val3 = DateTime.Now;
                    writeToLog(action, val1, val2, val3);
                    break;

                }
            }

            if (!found)
            {
                Console.WriteLine("The event could not be found!");
            }

        }
        private static void bookTickets()
        {
            int evID = inputInt("What is the event ID you wish to book?: >");

            Boolean found = false;

            for (int i = 0; i < events.Count; i++)
            {
                EveStorage details = (EveStorage)events[i];
                if (details.EID == evID || found)
                {
                    String customerName = inputString("What is your name? >");
                    String address = inputString("What is your address? >");
                    int tickTotal = inputInt("What is the total number of tickets you wish to buy?: >");
                    submitBooking(customerName, address, evID, tickTotal);
                    string action = "Booking Tickets";
                    string val1 = "";
                    string val2 = ("Event ID: " + evID + " Ticket Num: " + tickTotal);
                    DateTime val3 = DateTime.Now;
                    writeToLog(action, val1, val2, val3);
                    string evname = "??";
                    double toPay = 0;
                    foreach (EveStorage j in events)
                    {
                        if (j.EID == evID)
                        {
                            found = true;
                            toPay = (j.TPrice*tickTotal);
                            evname = j.EName;
                            Console.WriteLine("Booking ID: " + (bookingID-1));
                            Console.WriteLine("Your booking for " + evname + " has been recorded! You need to pay: £" + toPay);
                        }
                    }
                }
            }
            if (!found)
            {
                Console.WriteLine("There is no event linked to this ID!");
            }



        }
        private static void viewEvents()

        {

            Console.WriteLine("");
            foreach (EveStorage i in events)
            {
                Console.WriteLine("Event ID: " + i.EID);
                Console.WriteLine("Event name: " + i.EName);
                Console.WriteLine("Event date: " + i.EDate);
                Console.WriteLine("Total Tickets: " + i.TTickets);
                Console.WriteLine("Ticket price: £" + i.TPrice);
                Console.WriteLine("Time date of entry: " + i.DATE);
                Console.WriteLine("");
            }
            Console.WriteLine("--- ");
            Console.WriteLine("");
            foreach (BookStorage j in bookings)
            {
                Console.WriteLine("Booking ID: " + j.BID);
                Console.WriteLine("Booking name: " + j.BName);
                Console.WriteLine("Booking address: " + j.Address);
                Console.WriteLine("Event ID booked: " + j.EventID);
                Console.WriteLine("Tickets booked: " + j.TTickets);
                Console.WriteLine("");

            }
            Console.WriteLine("--- ");
            Console.WriteLine("");
        }
        private static void viewTransactionLog()

        {
            Console.WriteLine("");
            foreach (TransactionLog i in transactions)
            {
                Console.WriteLine(i.Whatadded + " - " + i.RecordedID1 + " "+ i.RecordedID2 + " " + i.DAT);
            }
            Console.WriteLine("");
        }
        private static void deleteEvent()
        {
            int ID = inputInt("What is the booking ID you wish to delete?: >");
            Boolean found = false;

            for (int i = 0; i < events.Count; i++)
            {
                EveStorage details = (EveStorage)events[i];
                if (details.EID == ID || found)
                {
                    events.Remove(details);
                    found = true;
                    Console.WriteLine("The event has been removed!");
                    string action = "Deleting Event";
                    string val1 = ("Event ID: "+ID);
                    string val2 = "";
                    DateTime val3 = DateTime.Now;
                    writeToLog(action, val1, val2, val3);

                }
            }

            if (!found)
            {
                Console.WriteLine("There is no event linked to this ID!");
            }
        }
        private static void deleteBooking()
        {
            int ID = inputInt("What is the booking ID you wish to delete?: >");
            Boolean found = false;

            for (int i = 0; i < bookings.Count; i++)
            {
                BookStorage details = (BookStorage)bookings[i];
                if (details.BID == ID || found)
                {
                    bookings.Remove(details);
                    found = true;
                    Console.WriteLine("The booking has been removed!");
                    string action = "Deleting Booking";
                    string val1 = ("Booking ID: " + ID);
                    string val2 = "";
                    DateTime val3 = DateTime.Now;
                    writeToLog(action, val1, val2, val3);

                }
            }

            if (!found)
            {
                Console.WriteLine("There is no booking linked to this ID!");
            }
        }


        // Input area, these inputs also have error checking (Less/ more than value, wrong input in field)
        private static int inputInt(string sentence)
        {
            Boolean legal = false;
            Console.Write(sentence);
            int input = 0;
            do
            {
                try
                {
                    input = Convert.ToInt32(Console.ReadLine());
                    if (input < 1)
                    {
                        Console.Write("You cannot enter a negative number or zero! >");
                    }
                    else
                    {
                        legal = true;
                    }
                    
                }
                catch (System.FormatException)
                {
                    Console.Write("Please enter an integer! >");
                }

            }
            while (!legal);
            return input;
        }
        private static string inputString(string sentence)
        {
            Console.Write(sentence);
            return Console.ReadLine();
        }
        private static string inputDate()
        {
            DateTime dt = DateTime.Today;
            int inputy = 0;
            int inputm = 0;
            int inputd = 0;
            int currentY = dt.Year;
            int currentD = dt.Day;
            int currentM = dt.Month;
            Boolean legal = false;
            Console.Write("What is the year this event is happening? >");
            do
            {
                try
                {
                    inputy = Convert.ToInt32(Console.ReadLine());
                    if (inputy < currentY)
                    {
                        Console.Write("You cannot enter a year less than the current year! >");
                    }
                    else
                    {
                        legal = true;
                    }
                }
                catch (System.FormatException)
                {
                    Console.Write("Please enter an integer! >");
                }
            }
            while (!legal);
            legal = false;
            Console.Write("What is the month this event is happening? (Written as a number) >");
            do
            {
                try
                {
                    inputm = Convert.ToInt32(Console.ReadLine());
                    if (inputm < currentM)
                    {
                        Console.Write("You cannot enter a number less than the current month! >");
                    }
                    else if (inputm > 12)
                    {
                        Console.Write("You cannot enter a number higher than 12! >");
                    }
                    else
                    {
                        legal = true;
                    }
                }
                catch (System.FormatException)
                {
                    Console.Write("Please enter an integer! >");
                }
            }
            while (!legal);
            int dim = DateTime.DaysInMonth(inputy, inputm);
            legal = false;
            Console.Write("What is the day this event is happening? (Written as a number) >");
            do
            {
                try
                {
                    inputd = Convert.ToInt32(Console.ReadLine());
                    if (inputd < currentD && currentM == inputm && currentY == inputy)
                    {
                        Console.Write("You cannot enter a number less than the current day! >");
                    }
                    else if (inputd > dim)
                    {
                        Console.Write("You cannot enter a number higher than the amount of days in that month! >");
                    }
                    else
                    {
                        legal = true;
                    }
                }
                catch (System.FormatException)
                {
                    Console.Write("Please enter an integer! >");
                }
            }
            while (!legal);

            string totaldate = (inputd + "/" + inputm + "/" + inputy);

            return totaldate;
        }
        private static double inputDouble(string sentence)
        {
            Boolean legal = false;
            Console.Write(sentence);
            double input = 0;
            do
            {
                try
                {
                    input = Convert.ToDouble(Console.ReadLine());
                    if (input <= 0)
                    {
                        Console.Write("You cannot enter a negative number or zero! >");
                    }
                    else
                    {
                        legal = true;
                    }

                }
                catch (System.FormatException)
                {
                    Console.Write("Please enter a double! >");
                }
            }
            while (!legal);
            return input;
        }
    }
}
