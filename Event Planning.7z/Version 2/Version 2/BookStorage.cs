﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Version_2
{
    class BookStorage
    {
        private string name = "?";
        private string add = "??";
        private int evID = 0;
        private int ticktotal = 0;
        private int idofbooking;

        public int BID
        {

            get { return idofbooking; }

            set
            {
                idofbooking = value;
            }
        }
        public string BName
        {

            get { return name; }

            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                {
                    name = value;
                }
            }
        }

        public string Address
        {

            get { return add; }

            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                {
                    add = value;
                }
            }
        }

        public int EventID
        {

            get { return evID; }

            set
            {
                if (value <= 0)
                {

                }
                else
                {
                    evID = value;
                }
            }
        }

        public int TTickets
        {

            get { return ticktotal; }

            set
            {
                if (value <= 0)
                {

                }
                else
                {
                    ticktotal = value;
                }
            }
        }
    }
}
