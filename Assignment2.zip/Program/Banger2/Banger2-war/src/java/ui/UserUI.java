/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

/**
 *
 * @author x74po
 */
import client.ABIReader;
import client.CSVRead;
import client.EmailClient;
import client.WebScraper;
import dto.BookingDTO;
import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import ejb.Member_UIRemote;
import java.util.Collection;
import javax.ejb.EJB;
import javax.inject.Named;
import ejb.User_UIRemote;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Paths;
import java.sql.Blob;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;
import org.apache.commons.io.IOUtils;


/**
 *
 * @author x74po
 */
@Named(value = "userUI")
@SessionScoped
public class UserUI implements Serializable {

    @EJB
    private User_UIRemote user_UI_session_bean;
    @EJB
    private Member_UIRemote member_UI_session_bean;

    private int userID;
    private String name = "Guest";
    private String email;
    private String password;
    private Boolean isAdmin;
    private Boolean banned;
    private MemberDTO loggedMember;
    private VehicleDTO savedVehicle;
    private Date currentNow;
    private String licenseNumber;
    private Blob additionalID;
    private Blob license;
    private String firstName;
    private String lastName;
    private BookingDTO bookingDTO;
    private Date DOB;
    
    private Part uploadedFile1;
    private Part uploadedFile2;
    private String fileName1;
    private String fileName2;
    private byte[] fileContents1;
    private byte[] fileContents2;
    private byte[] tempAdditionalID;
    private byte[] licenseImg;

    public UserUI() {
    }
    
    public String prepCollectVehicle(BookingDTO theBooking)
    {
        
        this.bookingDTO = theBooking;
        return "collectVehicle";
    }
    
    public void image1()
    {
        fileName1 = Paths.get(uploadedFile1.getSubmittedFileName()).getFileName().toString();
        
        try(InputStream input = uploadedFile1.getInputStream())
        {
            fileContents1 = IOUtils.toByteArray(input);
            tempAdditionalID = fileContents1;
            
        }
        catch (IOException e)
        {
            
        }
    }
    
    public void image2()
    {
        fileName2 = Paths.get(uploadedFile2.getSubmittedFileName()).getFileName().toString();
        
        try(InputStream input = uploadedFile2.getInputStream())
        {
            fileContents2 = IOUtils.toByteArray(input);
            licenseImg = fileContents2;
            
        }
        catch (IOException e)
        {
            
        }
    }

    public Part getUploadedFile1() {
        return uploadedFile1;
    }

    public void setUploadedFile1(Part uploadedFile1) {
        this.uploadedFile1 = uploadedFile1;
    }

    public Part getUploadedFile2() {
        return uploadedFile2;
    }

    public void setUploadedFile2(Part uploadedFile2) {
        this.uploadedFile2 = uploadedFile2;
    }
    
    

    public String register() {
        user_UI_session_bean.registerUser(new MemberDTO(-1, name, email, password, false, false, DOB));
        return loginUser();
    }

    public String loginUser() {
        String loginRoute;
        MemberDTO detectedUser = user_UI_session_bean.loginUser(email, password);
        if (detectedUser != null) {
            loginRoute = "mainPage";
            setLoggedMember(detectedUser);
        }
        else {
            FacesContext.getCurrentInstance().addMessage("", new FacesMessage("The user with the following login details could not be found!"));
            loginRoute = null;
            setLoggedMember(detectedUser);
        }
        return loginRoute;
    }

    public String loadMyBookings() {
        return "myBookingsPage.xhtml";
    }

    public String logoutUser() {
        user_UI_session_bean.logoutUser();
        loggedMember = null;
        return "index.xhtml";
    }

    public String viewVehicle(int vehicleID) {
        user_UI_session_bean.getVehicle(vehicleID);
        return "mainPage.xhtml";
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Boolean getBanned() {
        return banned;
    }

    public void setBanned(Boolean banned) {
        this.banned = banned;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public Member_UIRemote getMember_UI_session_bean() {
        return member_UI_session_bean;
    }

    public Blob getAdditionalID() {
        return additionalID;
    }

    public BookingDTO getBookingDTO() {
        return bookingDTO;
    }

    public void setBookingDTO(BookingDTO bookingDTO) {
        this.bookingDTO = bookingDTO;
    }

    public Blob getLicense() {
        return license;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setAdditionalID(Blob additionalID) {
        this.additionalID = additionalID;
    }

    public void setLicense(Blob license) {
        this.license = license;
    }

    public void setFirstName(String fName) {
        this.firstName = fName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }
    
    

    public User_UIRemote getUser_UI_session_bean() {
        return user_UI_session_bean;
    }

    public void setUser_UI_session_bean(User_UIRemote user_UI_session_bean) {
        this.user_UI_session_bean = user_UI_session_bean;
    }

    public Collection<VehicleDTO> getAllVehicles() {
        WebScraper scraper = new WebScraper();
        ArrayList<Integer> scrapedCars = scraper.fetchCars();
        Collection<VehicleDTO> list = user_UI_session_bean.getAllVehicles();
        int i = 0;
        double price = 0;
        for (VehicleDTO vehicle : list)
        {
            price = Math.round(scrapedCars.get(i)*0.95*100.0)/100.0;
            if (vehicle.getCostPerDay()>price)
            {
                user_UI_session_bean.changePrice(vehicle.getVehicleID(), price);
            }
            i++;
            
        }
        list = user_UI_session_bean.getAllVehicles();
        
        
        
        return list;
    }

    public String getVehicleByID(int vehicleID) {
        setSavedVehicle(null);
        String route = "index";
        VehicleDTO vehicle = user_UI_session_bean.getVehicle(vehicleID);
        if (vehicle != null) {
            route = "addBooking";
            setSavedVehicle(vehicle);
        }
        return route;
    }
    
    public String viewVehicleByID(int vehicleID) {
        setSavedVehicle(null);
        String route = "index";
        VehicleDTO vehicle = user_UI_session_bean.getVehicle(vehicleID);
        if (vehicle != null) {
            route = "singleVehicle";
            setSavedVehicle(vehicle);
        }
        return route;
    }
    
    public String submitCollectRequest(String fName, String lName, String licenseNum)
    {
        
        try
        {
            if (setTimedBookingStatus(bookingDTO, "Request", fName, lName, licenseNum))
            {
                RequestDTO reqDTO = new RequestDTO(-1, bookingDTO.getBookingID(), firstName, lastName, licenseNumber, tempAdditionalID, licenseImg, false, false);
                user_UI_session_bean.registerCollection(reqDTO);
                return "successRequest";
            }
            else
            {
                FacesContext.getCurrentInstance().addMessage("", new FacesMessage("Something went wrong! Our team will notify you of any changes to your application."));
                return "";
            }
            
            
        }
        catch(Exception e)
        {
            FacesContext.getCurrentInstance().addMessage("", new FacesMessage("Error: "+e));
            return "";
        }
        
        
    }
    
    public boolean setTimedBookingStatus(BookingDTO theBooking, String theString, String fName, String lName, String licenseNum){
        boolean legal = true;
        EmailClient emailer = new EmailClient();
        ABIReader abiReader = new ABIReader();
        CSVRead csvReader = new CSVRead();
        String additionalString = "";
        if (abiReader.readABI(fName, lName))
        {
            legal = false;
            additionalString+="\nThe user "+fName+" "+lName+" has comitted drivers fraud.";
        }
        //String license = "DUCKO504067DD7UM";
        if (csvReader.readCSV(licenseNum))
        {
            legal = false;
            additionalString+="\nThe user "+licenseNum+" has a suspended license.";
        }
        if (!legal)
        {
            emailer.sendEmail(licenseNum, additionalString);
        }
        else
        {
            Calendar rightNow = Calendar.getInstance();
            int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
            if (currentHour >= 8 && currentHour < 18) {}//Anyone can make a request at any time of the day.
            member_UI_session_bean.setBookingStatus(theBooking, theString);
        }
        
        
        return legal;
    }

    public MemberDTO getLoggedMember() {
        loggedMember = user_UI_session_bean.getMemberByID(loggedMember);
        return loggedMember;
    }

    public void setLoggedMember(MemberDTO loggedMember) {
        this.loggedMember = loggedMember;
    }

    public VehicleDTO getSavedVehicle() {
        return savedVehicle;
    }

    public void setSavedVehicle(VehicleDTO savedVehicle) {
        this.savedVehicle = savedVehicle;
    }

    public Date getCurrentNow() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        Date nowDate = new Date();
        setCurrentNow(nowDate);
        return currentNow;
    }

    public void setCurrentNow(Date currentNow) {
        this.currentNow = currentNow;

    }

    public Date getDOB() {
        return DOB;
    }

    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    public double getCost(BookingDTO booking)
    {
        Double VehicleCost = 1.00;
        Collection<VehicleDTO> collection = getAllVehicles();
        for (VehicleDTO v: collection)
        {
            if (v.getVehicleID() == booking.getCarID())
            {
                VehicleCost = v.getCostPerDay();
            }
        }
        Long dateDifference = booking.getEndDate().getTime() - booking.getStartDate().getTime();
        
        Double cost = (double)TimeUnit.MILLISECONDS.toDays(dateDifference);
        cost = (cost*VehicleCost);
        return Math.round(cost*100.0)/100.0;
    }
    
}
