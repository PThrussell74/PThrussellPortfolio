/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

/**
 *
 * @author x74po
 */
import client.ABIReader;
import client.CSVRead;
import client.EmailClient;
import dto.BookingDTO;
import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import ejb.Member_UIRemote;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "memberUI")
@RequestScoped
public class MemberUI {

    @EJB
    private Member_UIRemote member_UI_session_bean;

    private Collection<VehicleDTO> vehicleCollection;

    private int bookingID;
    private int userID;
    private Date startDate;
    private Date endDate;
    private int carID;
    private Boolean satNav;
    private Boolean carSeat;
    private Boolean wineChiller;
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");

    public MemberUI() {
    }
    

    public String makeBooking(int passedUserID, int passedCarID) {
        String destination;
        Date date = new Date();
        date.getTime();
        double dateDifference = calculateDifferenceInDays(startDate, endDate);
        
        BookingDTO theDTO = new BookingDTO(-1, passedUserID, startDate, endDate, passedCarID, satNav, carSeat, wineChiller, "Not Ready");
        
        Boolean legal = member_UI_session_bean.checkBookingCollision(theDTO, passedCarID);
        
        if (dateDifference < 14 && dateDifference >= 0.5 && legal) {
            member_UI_session_bean.createBooking(theDTO); //DTO is established
            destination = "success.xhtml";
        }
        else
        {
            FacesContext.getCurrentInstance().addMessage("", new FacesMessage("The selected vehicle has been booked during this period. Pleas refer to the booking table."));
            destination = null;
        }
        return destination;
    }

    public double calculateDifferenceInDays(Date date1, Date date2) {
        return (date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24) % 365;
    }

    public Collection<BookingDTO> getAllBookings() {
        Collection<BookingDTO> list = member_UI_session_bean.getAllBookings();
        for (BookingDTO m : list) {
            BookingDTO tempBooking = getBookingByID(m.getBookingID());
            member_UI_session_bean.updateStatus(tempBooking);
            if (tempBooking.getStatus().equals("Failed to Collect"))
            {
                member_UI_session_bean.ban(tempBooking.getUserID());
            }
        }
        return list;
    }

    public Collection<BookingDTO> getAllMyBookings(MemberDTO theMember) {
        Collection<BookingDTO> list = member_UI_session_bean.getAllMyBookings(theMember);
        for (BookingDTO m : list) {
            BookingDTO tempBooking = getBookingByID(m.getBookingID());
            member_UI_session_bean.updateStatus(tempBooking);
            if (tempBooking.getStatus().equals("Failed to Collect"))
            {
                member_UI_session_bean.ban(theMember.getUserID());
            }
        }
        return list;
    }

    public BookingDTO getBookingByID(int ID) {
        return member_UI_session_bean.getBookingByID(ID);
    }
    
    public Collection<BookingDTO> getBookingsByVehicleID(int ID) {
        Collection<BookingDTO> list = member_UI_session_bean.getBookingsByVehicleID(ID);
        return list;
    }
        

    public String collectEquipment(int equipmentID, int userID) {
        //Sets equipment's On premises to false
        member_UI_session_bean.collectEquipment(equipmentID, userID);
        return "NULL.html";
    }

    public String collectVehicle(int vehicleID, int userID) {
        //Sets vehicle's On premises to false
        
        member_UI_session_bean.collectVehicle(vehicleID, userID);
        return null;
    }

    public String extendVehicleRent(BookingDTO theBooking, int daysOfRental) {
        //Extends rental by the amount of days provided.
        member_UI_session_bean.extendVehicleRent(theBooking, daysOfRental);
        return null;
    }

    public String rentEquipment(int equipmentID, int userID, double daysOfRental) {
        //Sets borrowedby to the userID.
        //Calculates the return date with daysOfRental. 0.5 is half a day.
        member_UI_session_bean.rentEquipment(equipmentID, userID, daysOfRental);
        return null;
    }

    public String rentVehicle(int vehicleID, int userID, double daysOfRental) {
        //Sets borrowedby to the userID.
        //Calculates the return date with daysOfRental. 0.5 is half a day.
        member_UI_session_bean.rentVehicle(vehicleID, userID, daysOfRental);
        return null;
    }

    public String returnVehicle(int vehicleID) {
        //Sets equipment's On premises to true
        //Sets borrowedby to Null.
        member_UI_session_bean.returnVehicle(vehicleID);
        return null;
    }

    public String returnEquipment(int equipmentID) {
        //Sets equipment's On premises to true
        //Sets borrowedby to Null.
        member_UI_session_bean.returnEquipment(equipmentID);
        return null;
    }

    public Collection<VehicleDTO> getVehicleCollection() {
        Collection<VehicleDTO> list = member_UI_session_bean.getVehicleCollection();
        return list;
    }

    public void setVehicleCollection(Collection<VehicleDTO> vehicles) {
        this.vehicleCollection = vehicles;
    }

    public Member_UIRemote getMember_UI_session_bean() {
        return member_UI_session_bean;
    }

    public void setMember_UI_session_bean(Member_UIRemote member_UI_session_bean) {
        this.member_UI_session_bean = member_UI_session_bean;
    }

    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getCarID() {
        return carID;
    }

    public void setCarID(int carID) {
        this.carID = carID;
    }

    public Boolean getSatNav() {
        return satNav;
    }

    public void setSatNav(Boolean satNav) {
        this.satNav = satNav;
    }

    public Boolean getCarSeat() {
        return carSeat;
    }

    public void setCarSeat(Boolean carSeat) {
        this.carSeat = carSeat;
    }

    public Boolean getWineChiller() {
        return wineChiller;
    }

    public void setWineChiller(Boolean wineChiller) {
        this.wineChiller = wineChiller;
    }

    public void setBookingStatus(BookingDTO theBooking, String theString) {
        member_UI_session_bean.setBookingStatus(theBooking, theString);
    }

    public void setTimedBookingStatus(int theBooking, String theString, RequestDTO request) //Commented out as it is now run elsewhere.
    {
//        EmailClient emailer = new EmailClient();
//        ABIReader abiReader = new ABIReader();
//        CSVRead csvReader = new CSVRead();
//        String additionalString = "";
//        String familyName = "DUCK";
//        if (abiReader.readABI(theString, theString))
//        {
//            additionalString+="\nThe user "+familyName+" has comitted drivers fraud.";
//        }
//        String license = "DUCKO504067DD7UM";
//        if (csvReader.readCSV(license))
//        {
//            additionalString+="\nThe user "+license+" has a suspended license.";
//        }
//        emailer.sendEmail(123, additionalString);

        BookingDTO booking = getBookingByID(theBooking);
        Calendar rightNow = Calendar.getInstance();
        int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
        if (currentHour >= 8 && currentHour < 18) {
            member_UI_session_bean.setCheckedStatue(true, request);
            member_UI_session_bean.setBookingStatus(booking, theString);
        }
    }
    
    public void setTimedBookingStatus(BookingDTO theBooking, String theString) //The original version, now only used for returning vehicles.
    {
        Calendar rightNow = Calendar.getInstance();
        int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
        if (currentHour >= 8 && currentHour < 18) {
            member_UI_session_bean.setBookingStatus(theBooking, theString);
        }
    }
    

    

}
