package ui;

import dto.MemberDTO;
import dto.VehicleDTO;
import dto.RequestDTO;
import java.util.Collection;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import ejb.Admin_UIRemote;
import java.util.Base64;

@Named(value = "adminUI")
@RequestScoped
public class AdminUI {

    @EJB
    private Admin_UIRemote admin_UI_session_bean;

    private Collection<VehicleDTO> vehicleCollection;

    public AdminUI() {
    }

    
    public String removeUser(int userID) {
        admin_UI_session_bean.removeUser(userID);
        return "userPage.xhtml";
    }
    
    public String banUser(int userID) {
        admin_UI_session_bean.banUser(userID);
        return "userPage.xhtml";
    }

    public String viewMember(int userID) {
        admin_UI_session_bean.viewMember(userID);
        return "mainPage.xhtml";
    }

    public Collection<MemberDTO> getAllMembers() {
        Collection<MemberDTO> list = admin_UI_session_bean.getAllUsers();
        return list;
    }

    public Collection<RequestDTO> getAllRequests() {
        Collection<RequestDTO> list = admin_UI_session_bean.getAllRequests();
        return list;
    }

    public String receivevehicle(int vehicleID) {
        admin_UI_session_bean.receiveVehicle(vehicleID);
        return "mainPage.xhtml";
    }
    
    public String getImage(byte[] b){
         String imageString = new String(Base64.getEncoder().encodeToString(b));
         return imageString;
     }

}
