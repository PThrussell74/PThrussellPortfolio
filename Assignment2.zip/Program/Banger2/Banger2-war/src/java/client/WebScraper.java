/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author x74po
 */
public class WebScraper 
{

    public ArrayList<Integer> fetchCars()
    {
        
        ArrayList<Integer> tempCars = new ArrayList();
        
        try
        {
            

            
            Document d = SSLSide.getConnection("https://www.kayak.co.uk/England-United-Kingdom-Hire-cars.3996.crr.html")
                .get();
            
            System.out.println("JSoup Text test 1:\n");
            Elements ele = d.getElementsByTag("TR");
            //System.out.println(ele);
            String details = "";
            for (Element element: ele)
            {
                details = element.select("td.rUzP-name").text();
                 if(details.equals("Economy") || details.equals("Intermediate") || details.equals("Premium"))
                 {
                     tempCars.add(Integer.parseInt(element.select("td.rUzP-price").text().replace("£", "").replace("/day", "")));        
                     tempCars.add(Integer.parseInt(element.select("td.rUzP-price").text().replace("£", "").replace("/day", "")));                        
                 }
                 if(details.equals("Standard")||details.equals("People carrier"))
                 {
                     tempCars.add(Integer.parseInt(element.select("td.rUzP-price").text().replace("£", "").replace("/day", ""))); 
                 }
            }
        }
        catch(Exception e)
        {
            System.out.println("My Error: "+e);
        }
        return tempCars;
    }

}
