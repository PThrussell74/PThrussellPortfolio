/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author x74po
 */
public class ABIReader {

    public boolean readABI(String fName, String lName) {
        boolean toReturn = false;
        try {

            String path = "jdbc:ucanaccess://";
            path += Paths.get(".").toAbsolutePath().normalize().toString();
            path += "\\ABI_DRIVER_FRAUD.accdb";
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection conn = DriverManager.getConnection(path);
            Statement s = conn.createStatement();
            String checker;
            String check2;
            ResultSet rs = s.executeQuery("SELECT [FAMILY_NAME] FROM [fraudulent_claim_data]");
            while (rs.next()) {
                checker = rs.getString(1).toLowerCase();
                check2 = lName.toLowerCase();
                if (checker.equals(check2))
                {
                    ResultSet rs2 = s.executeQuery("SELECT [FORENAMES] FROM [fraudulent_claim_data]");
                    while (rs2.next()) {
                    checker = rs2.getString(1).toLowerCase();
                    check2 = fName.toLowerCase();
                    if (checker.equals(check2))
                    {
                        toReturn= true;
                    }
                    }
            }
            }
        } catch (Exception e) {
            System.out.println("My error:" + e);
        }
        
        return toReturn;
    }
}
