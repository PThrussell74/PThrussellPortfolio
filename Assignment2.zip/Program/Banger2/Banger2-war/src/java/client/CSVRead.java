/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;


import com.opencsv.CSVReader;
import java.io.FileReader;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class CSVRead {
    
    public boolean readCSV(String passedString)
    {
        boolean found = false;
        try {
            String path = Paths.get(".").toAbsolutePath().normalize().toString();

            path = "C:\\Users\\x74po\\Desktop\\DVLA\\dvla.csv";

            CSVReader reader = new CSVReader(new FileReader(path));

            String[] nextLine;
            int lineNumber = 0;
            ArrayList<String> DVLANumbers = new ArrayList<>();

            reader.readNext(); //skipping 1st line

            while ((nextLine = reader.readNext()) != null) {
                DVLANumbers.add(nextLine[0]);
                if(nextLine[0].equals(passedString)&&nextLine[8].equals("Suspended"))
                {
                    found = true;
                }
            }
        } catch (Exception e) {
            System.out.println("My Error: "+e);
        }
        return found;
    }
    
}
