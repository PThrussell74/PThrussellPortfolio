/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.time.Instant;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author x74po
 */
public class EmailClient {
    
    public EmailClient()
    {
    }
    
    public void sendEmail(String ID, String additionalText)
    {

        final String username = "throwawayeirlss";
        final String password = "EIRLSSisLove";
        Date now = Date.from(Instant.now());

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
          });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("throwawayeirlss@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse("x74potions@hotmail.co.uk"));
            message.setSubject("Banger2 - DVLA notice");
            message.setText("To whom it concerns at the DVLA,"
                + "\n Banger (Facility ID: 000000074789132) has detected a user (License ID: "+ID+") attempting to interact with our system while using a lost, stolen or suspended license."
                + "\n The date of the occurance was "+now
                + additionalText);

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
    
}
