/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

/**
 *
 * @author x74po
 */
public class ScrapeVehicleDTO {
    
    private String carDetails;
    private int price;

    public ScrapeVehicleDTO(String carDetails, int price) {
        this.carDetails = carDetails;
        this.price = price;
    }

    public String getCarDetails() {
        return carDetails;
    }

    public void setCarDetails(String carDetails) {
        this.carDetails = carDetails;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    public void setAll(String carDetails, int price) {
        this.price = price;
        this.carDetails = carDetails;
    }

    @Override
    public String toString() {
        return "\n"+carDetails+" - £"+price; //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
