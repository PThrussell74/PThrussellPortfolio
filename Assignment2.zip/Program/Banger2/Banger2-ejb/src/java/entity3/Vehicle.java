/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity3;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author x74po
 */
@Entity
@Table(name = "VEHICLE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Vehicle.findAll", query = "SELECT v FROM Vehicle v"),
    @NamedQuery(name = "Vehicle.findByVehicleid", query = "SELECT v FROM Vehicle v WHERE v.vehicleid = :vehicleid"),
    @NamedQuery(name = "Vehicle.findByName", query = "SELECT v FROM Vehicle v WHERE v.name = :name"),
    @NamedQuery(name = "Vehicle.findByCostperday", query = "SELECT v FROM Vehicle v WHERE v.costperday = :costperday")})
    @NamedNativeQueries(
            {
                @NamedNativeQuery(name = "Vehicle.changePrice", query = "UPDATE Vehicle SET COSTPERDAY = ? WHERE VEHICLEID = ?")
            })
public class Vehicle implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "VEHICLEID")
    private Integer vehicleid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "NAME")
    private String name;
    @Column(name = "COSTPERDAY")
    private Double costperday;

    public Vehicle() {
    }

    public Vehicle(Integer vehicleid) {
        this.vehicleid = vehicleid;
    }

    public Vehicle(Integer vehicleid, String name) {
        this.vehicleid = vehicleid;
        this.name = name;
    }

    public Integer getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(Integer vehicleid) {
        this.vehicleid = vehicleid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getCostperday() {
        return costperday;
    }

    public void setCostperday(Double costperday) {
        this.costperday = costperday;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (vehicleid != null ? vehicleid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vehicle)) {
            return false;
        }
        Vehicle other = (Vehicle) object;
        if ((this.vehicleid == null && other.vehicleid != null) || (this.vehicleid != null && !this.vehicleid.equals(other.vehicleid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity3.Vehicle[ vehicleid=" + vehicleid + " ]";
    }
    
}
