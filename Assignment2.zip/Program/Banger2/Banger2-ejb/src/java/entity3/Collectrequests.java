/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity3;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author x74po
 */
@Entity
@Table(name = "COLLECTREQUESTS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Collectrequests.findAll", query = "SELECT c FROM Collectrequests c"),
    @NamedQuery(name = "Collectrequests.findByRequestid", query = "SELECT c FROM Collectrequests c WHERE c.requestid = :requestid"),
    @NamedQuery(name = "Collectrequests.findByBookingid", query = "SELECT c FROM Collectrequests c WHERE c.bookingid = :bookingid"),
    @NamedQuery(name = "Collectrequests.findByFname", query = "SELECT c FROM Collectrequests c WHERE c.fname = :fname"),
    @NamedQuery(name = "Collectrequests.findByLname", query = "SELECT c FROM Collectrequests c WHERE c.lname = :lname"),
    @NamedQuery(name = "Collectrequests.findByLicenseno", query = "SELECT c FROM Collectrequests c WHERE c.licenseno = :licenseno"),
    @NamedQuery(name = "Collectrequests.findByChecked", query = "SELECT c FROM Collectrequests c WHERE c.checked = :checked"),
    @NamedQuery(name = "Collectrequests.findByIllegal", query = "SELECT c FROM Collectrequests c WHERE c.illegal = :illegal")})
    @NamedNativeQueries(
            {
                @NamedNativeQuery(name = "Collectrequests.setChecked", query = "UPDATE Collectrequests SET CHECKED = ? WHERE REQUESTID = ?")
            })
public class Collectrequests implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "REQUESTID")
    private Integer requestid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "BOOKINGID")
    private int bookingid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "FNAME")
    private String fname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "LNAME")
    private String lname;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LICENSENO")
    private String licenseno;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LICENSESCAN")
    private Serializable licensescan;
    @Lob
    @Column(name = "ADDITIONALID")
    private Serializable additionalid;
    @Column(name = "CHECKED")
    private Boolean checked;
    @Column(name = "ILLEGAL")
    private Boolean illegal;

    public Collectrequests() {
    }

    public Collectrequests(Integer requestid) {
        this.requestid = requestid;
    }

    public Collectrequests(Integer requestid, int bookingid, String fname, String lname, String licenseno) {
        this.requestid = requestid;
        this.bookingid = bookingid;
        this.fname = fname;
        this.lname = lname;
        this.licenseno = licenseno;
    }

    public Integer getRequestid() {
        return requestid;
    }

    public void setRequestid(Integer requestid) {
        this.requestid = requestid;
    }

    public int getBookingid() {
        return bookingid;
    }

    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLicenseno() {
        return licenseno;
    }

    public void setLicenseno(String licenseno) {
        this.licenseno = licenseno;
    }

    public Serializable getLicensescan() {
        return licensescan;
    }

    public void setLicensescan(Serializable licensescan) {
        this.licensescan = licensescan;
    }

    public Serializable getAdditionalid() {
        return additionalid;
    }

    public void setAdditionalid(Serializable additionalid) {
        this.additionalid = additionalid;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public Boolean getIllegal() {
        return illegal;
    }

    public void setIllegal(Boolean illegal) {
        this.illegal = illegal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (requestid != null ? requestid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Collectrequests)) {
            return false;
        }
        Collectrequests other = (Collectrequests) object;
        if ((this.requestid == null && other.requestid != null) || (this.requestid != null && !this.requestid.equals(other.requestid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity3.Collectrequests[ requestid=" + requestid + " ]";
    }
    
}
