/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity3;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author x74po
 */
@Entity
@Table(name = "BOOKINGS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bookings.findAll", query = "SELECT b FROM Bookings b"),
    @NamedQuery(name = "Bookings.findByBookingid", query = "SELECT b FROM Bookings b WHERE b.bookingid = :bookingid"),
    @NamedQuery(name = "Bookings.findByCarid", query = "SELECT b FROM Bookings b WHERE b.carid = :carid"),
    @NamedQuery(name = "Bookings.findByUserid", query = "SELECT b FROM Bookings b WHERE b.userid.userid = :userid"),
    @NamedQuery(name = "Bookings.findByUser", query = "SELECT b FROM Bookings b WHERE b.userid = :userid"),
    @NamedQuery(name = "Bookings.findByStartdate", query = "SELECT b FROM Bookings b WHERE b.startdate = :startdate"),
    @NamedQuery(name = "Bookings.findByEnddate", query = "SELECT b FROM Bookings b WHERE b.enddate = :enddate")})
    @NamedNativeQueries(
            {
                @NamedNativeQuery(name = "Bookings.setStatus", query = "UPDATE Bookings SET STATUS = ? WHERE BOOKINGID = ?"),
                @NamedNativeQuery(name = "Bookings.pushRent", query = "UPDATE Bookings SET ENDDATE = ? WHERE BOOKINGID = ?")
            })
public class Bookings implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "STATUS")
    private String status;

    @Basic(optional = false)
    @NotNull
    @Column(name = "CARID")
    private int carid;
    @Column(name = "SATNAV")
    private Boolean satnav;
    @Column(name = "CARSEAT")
    private Boolean carseat;
    @Column(name = "WINECHILLER")
    private Boolean winechiller;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "BOOKINGID")
    private Integer bookingid;
    @Column(name = "STARTDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startdate;
    @Column(name = "ENDDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date enddate;
    @JoinColumn(name = "USERID", referencedColumnName = "USERID")
    @ManyToOne(optional = false)
    private Users userid;
    

    public Bookings() {
    }

    public Bookings(Integer bookingid) {
        this.bookingid = bookingid;
    }

    public Integer getBookingid() {
        return bookingid;
    }

    public void setBookingid(Integer bookingid) {
        this.bookingid = bookingid;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public Users getUserid() {
        return userid;
    }

    public void setUserid(Users userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookingid != null ? bookingid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bookings)) {
            return false;
        }
        Bookings other = (Bookings) object;
        if ((this.bookingid == null && other.bookingid != null) || (this.bookingid != null && !this.bookingid.equals(other.bookingid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity3.Bookings[ bookingid=" + bookingid + " ]";
    }

    public int getCarid() {
        return carid;
    }

    public void setCarid(int carid) {
        this.carid = carid;
    }

    public Boolean getSatnav() {
        return satnav;
    }

    public void setSatnav(Boolean satnav) {
        this.satnav = satnav;
    }

    public Boolean getCarseat() {
        return carseat;
    }

    public void setCarseat(Boolean carseat) {
        this.carseat = carseat;
    }

    public Boolean getWinechiller() {
        return winechiller;
    }

    public void setWinechiller(Boolean winechiller) {
        this.winechiller = winechiller;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
