/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author x74po
 */
@Stateless
public class User_UI implements User_UIRemote {

    @EJB
    private VehicleHandlerRemote vehicleHandler;
    @EJB
    private RequestHandlerRemote requestHandler;
    @EJB
    private AdminHandlerRemote adminHandler;
    @EJB
    private BookingHandlerRemote bookingHandler;

    private MemberDTO loggedInUser = null;
    
    private VehicleDTO vehicleFocus = null;

    @Override
    public MemberDTO loginUser(String email, String password) {
        MemberDTO loginUser = adminHandler.loginUser(email, password);
        return loginUser;
    }

    @Override
    public void logoutUser() {
        //userHandler.logoutUser();
    }

    @Override
    public Collection<VehicleDTO> getAllVehicles() {
        return vehicleHandler.getAllVehicles();
    }

    @Override
    public Collection<VehicleDTO> getAllAvailableVehicles() {
        return null;
    }

    @Override
    public VehicleDTO getVehicle(int vehicleID) {
        return vehicleHandler.getVehicle(vehicleID);
    }

    public VehicleHandlerRemote getVehicleHandler() {
        return vehicleHandler;
    }

    public void setVehicleHandler(VehicleHandlerRemote vehicleHandler) {
        this.vehicleHandler = vehicleHandler;
    }

    @Override
    public void registerUser(MemberDTO member) {
        adminHandler.register(member);
    }

    public MemberDTO getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(MemberDTO loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    public VehicleDTO getVehicleFocus() {
        return vehicleFocus;
    }

    public void setVehicleFocus(VehicleDTO vehicleFocus) {
        this.vehicleFocus = vehicleFocus;
    }

    @Override
    public MemberDTO getMemberByID(MemberDTO loggedMember) {
        return adminHandler.getMemberByID(loggedMember);
    }

    @Override
    public void changePrice(int vehicleID, double newPrice) {
        vehicleHandler.changePrice(vehicleID, newPrice);
    }

    @Override
    public void registerCollection(RequestDTO requestDTO) {
        requestHandler.registerCollection(requestDTO);
    }
    
    
    
    

}
