/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.MemberDTO;
import dto.RequestDTO;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author x74po
 */
@Stateless
public class Admin_UI implements Admin_UIRemote {

    @EJB
    private AdminHandlerRemote theHandler;
    @EJB
    private RequestHandlerRemote requestHandler;

    @Override
    public void viewMember(int memberID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void receiveVehicle(int vehicleID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void businessMethod() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public Collection<MemberDTO> getAllUsers() {
        return theHandler.getAllUsers();
    }

    @Override
    public Collection<MemberDTO> getAllAvailableUsers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void removeUser(int memberID) {
        theHandler.deleteUser(memberID);
    }
    
    @Override
    public void banUser(int memberID) {
        theHandler.banUser(memberID);
    }

    
//
//    @Override
//    public Collection viewAllMembers() {
//        return adminHandler.viewAllMembers();
//    }
//
//    @Override
//    public void receiveVehicle(int vehicleID) {
//        adminHandler.receiveVehicle(vehicleID);
//    }
//
//    @Override
//    public void businessMethod() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public Admin_UIRemote getAdminHandler() {
//        return adminHandler;
//    }
//
//    public void setAdminHandler(Admin_UIRemote adminHandler) {
//        this.adminHandler = adminHandler;
//    }
//
//    public Member_UIRemote getMemberHandler() {
//        return memberHandler;
//    }
//
//    public void setMemberHandler(Member_UIRemote memberHandler) {
//        this.memberHandler = memberHandler;
//    }
//
//    public User_UIRemote getUserHandler() {
//        return userHandler;
//    }
//
//    public void setUserHandler(User_UIRemote userHandler) {
//        this.userHandler = userHandler;
//    }

    @Override
    public Collection<RequestDTO> getAllRequests() {
        return requestHandler.getAllRequestCollections();
    }


    
    
    
}
