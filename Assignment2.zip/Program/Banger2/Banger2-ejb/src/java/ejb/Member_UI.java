/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.BookingDTO;
import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author x74po
 */
@Stateless
public class Member_UI implements Member_UIRemote {

    @EJB
    private BookingHandlerRemote bookingHandler;
    @EJB
    private AdminHandlerRemote adminHandlerRemote;
    @EJB
    private RequestHandlerRemote requestHandlerRemote;

    

    @Override
    public void extendVehicleRent(BookingDTO vehicleID, int daysOfRental) {
        bookingHandler.extendBooking(vehicleID, daysOfRental);
    }


    @Override
    public void createBooking(BookingDTO booking) {
        bookingHandler.createBooking(booking);

    }
    
    @Override
    public Collection<BookingDTO> getAllBookings() {
        return bookingHandler.getAllBookings();
    }

    @Override
    public Collection<BookingDTO> getAllMyBookings(MemberDTO theMemberDTO) {
        return bookingHandler.getAllMyBookings(theMemberDTO);
    }
    
    @Override
    public BookingDTO getBookingByID(int bookingID) {
        return bookingHandler.getBookingByID(bookingID);
    }

    @Override
    public void updateStatus(BookingDTO tempBooking) {
        bookingHandler.updateStatus(tempBooking);
    }

    @Override
    public void setBookingStatus(BookingDTO tempBooking, String theStatus) {
        bookingHandler.setBookingStatus(tempBooking, theStatus);
    }

    @Override
    public Boolean checkBookingCollision(BookingDTO theDTO, int carID) {
        return bookingHandler.checkBookingCollision(theDTO, carID);
    }

    @Override
    public void ban(int theMember) {
        adminHandlerRemote.ban(theMember);
    }

    @Override
    public Collection<BookingDTO> getBookingsByVehicleID(int ID) {
        return bookingHandler.getAllBookingsViaCarID(ID);
    }

    @Override
    public void collectVehicle(int vehicleID, int userID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void rentEquipment(int equipmentID, int userID, double daysOfRental) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void collectEquipment(int equipmentID, int userID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void rentVehicle(int vehicleID, int userID, double daysOfRental) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void returnVehicle(int vehicleID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void returnEquipment(int equipmentID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<VehicleDTO> getVehicleCollection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setCheckedStatue(boolean b, RequestDTO req) {
        requestHandlerRemote.setCheckedStatue(b, req);
    }
    
    

}
