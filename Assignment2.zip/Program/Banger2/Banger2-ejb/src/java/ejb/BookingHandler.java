/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.BookingDTO;
import dto.MemberDTO;
import entity3.Bookings;
import entity3.Users;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author x74po
 */
@Stateless
public class BookingHandler implements BookingHandlerRemote {

    @PersistenceContext(unitName = "Banger2-ejbPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    private java.sql.Timestamp dateToSQL(java.util.Date theDate) {
        return new java.sql.Timestamp(theDate.getTime());

    }

    private java.util.Date SQLtoDate(java.sql.Timestamp theDate) {
        return new java.util.Date(theDate.getTime());

    }

    @Override
    public void createBooking(BookingDTO booking) {
        Object theUser = em.createNamedQuery("Users.findByUserid").setParameter("userid", booking.getUserID()).getSingleResult();
        Bookings u = new Bookings();
        u.setUserid((Users) theUser);
        u.setStartdate(booking.getStartDate());
        u.setEnddate(booking.getEndDate());
        u.setCarid(booking.getCarID());
        u.setSatnav(booking.getSatNav());
        u.setCarseat(booking.getCarSeat());
        u.setWinechiller(booking.getWineChiller());
        u.setStatus(booking.getStatus());
        try {
            persist(u);
        } catch (Exception e) {
            throw new EJBException("Error while creating a Booking!: ", e);
        }
    }

    @Override
    public Collection<BookingDTO> getAllBookings() {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Bookings> list = em.createNamedQuery("Bookings.findAll").getResultList();
        Collection<BookingDTO> bookingList = new ArrayList<>(list.size());
        for (Bookings b : list) {
            BookingDTO singleDTO = new BookingDTO(b.getBookingid(), b.getUserid().getUserid(), b.getStartdate(), b.getEnddate(), b.getCarid(), b.getSatnav(), b.getCarseat(), b.getWinechiller(), b.getStatus());
            bookingList.add(singleDTO);
        }
        return bookingList;
    }

    @Override
    public Collection<BookingDTO> getAllMyBookings(MemberDTO userDTO) {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Bookings> list = em.createNamedQuery("Bookings.findByUserid").setParameter("userid", userDTO.getUserID()).getResultList();
        Collection<BookingDTO> bookingList = new ArrayList<>(list.size());
        for (Bookings b : list) {
            BookingDTO bookingSingle = new BookingDTO(b.getBookingid(), b.getUserid().getUserid(), b.getStartdate(), b.getEnddate(), b.getCarid(), b.getSatnav(), b.getCarseat(), b.getWinechiller(), b.getStatus());
            bookingList.add(bookingSingle);
        }
        return bookingList;
    }

    public Users convertDTOToUser(MemberDTO theDTO) {
        return new Users(theDTO.getUserID(), theDTO.getEmail(), theDTO.getPassword(), theDTO.getName());
    }

    @Override
    public BookingDTO getBookingByID(int bookingID) {
        Bookings theBooking = getBookingAsBookingsObj(bookingID);
        BookingDTO vehicleDTOObj = new BookingDTO(
                theBooking.getBookingid(),
                theBooking.getUserid().getUserid(),
                theBooking.getStartdate(),
                theBooking.getEnddate(),
                theBooking.getCarid(),
                theBooking.getSatnav(),
                theBooking.getCarseat(),
                theBooking.getWinechiller(),
                theBooking.getStatus());
        return vehicleDTOObj;
    }

    public Bookings getBookingAsBookingsObj(int bookingID) {
        Object bookingObj = em.createNamedQuery("Bookings.findByBookingid").setParameter("bookingid", bookingID).getSingleResult();
        return (Bookings) bookingObj;
    }

    @Override
    public Collection<BookingDTO> getAllBookingsViaCarID(int ID) {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Bookings> list = em.createNamedQuery("Bookings.findByCarid").setParameter("carid", ID).getResultList();
        Collection<BookingDTO> bookingList = new ArrayList<>(list.size());
        for (Bookings b : list) {
            BookingDTO bookingSingle = new BookingDTO(b.getBookingid(), b.getUserid().getUserid(), b.getStartdate(), b.getEnddate(), b.getCarid(), b.getSatnav(), b.getCarseat(), b.getWinechiller(), b.getStatus());
            bookingList.add(bookingSingle);
        }
        return bookingList;
    }

    @Override
    public void updateStatus(BookingDTO tempBooking) {
        Date now = new Date();

        if (tempBooking.getEndDate().before(now) && ((tempBooking.getStatus().equals("Ready")) || (tempBooking.getStatus().equals("Not Ready")))) {
            Query q = em.createNamedQuery("Bookings.setStatus");
            q.setParameter(1, "Failed to Collect");
            q.setParameter(2, tempBooking.getBookingID());
            q.executeUpdate();
        }

        if (tempBooking.getStartDate().before(now) && tempBooking.getStatus().equals("Not Ready")) {
            Query q = em.createNamedQuery("Bookings.setStatus");
            q.setParameter(1, "Ready");
            q.setParameter(2, tempBooking.getBookingID());
            q.executeUpdate();
            if (tempBooking.getEndDate().before(now) && ((tempBooking.getStatus().equals("Ready")) || (tempBooking.getStatus().equals("Not Ready")))) {
                q = em.createNamedQuery("Bookings.setStatus");
                q.setParameter(1, "Failed to Collect");
                q.setParameter(2, tempBooking.getBookingID());
                q.executeUpdate();
            }
        }

        if (tempBooking.getEndDate().before(now) && (tempBooking.getStatus().equals("Collected"))) {
            Query q = em.createNamedQuery("Bookings.setStatus");
            q.setParameter(1, "Late");
            q.setParameter(2, tempBooking.getBookingID());
            q.executeUpdate();
        }
    }

    @Override
    public void setBookingStatus(BookingDTO tempBooking, String theStatus) {
        Query q = em.createNamedQuery("Bookings.setStatus");
        q.setParameter(1, theStatus);
        q.setParameter(2, tempBooking.getBookingID());
        q.executeUpdate();
    }

    @Override
    public Boolean checkBookingCollision(BookingDTO theDTO, int carID) {
        Date newStartDate = theDTO.getStartDate();
        Date newEndDate = theDTO.getEndDate();
        Boolean legal = true;
        Collection<BookingDTO> allBookings = getAllBookingsViaCarID(carID);
        for (BookingDTO b : allBookings) {
            Date oldStartDate = b.getStartDate();
            Date oldEndDate = b.getEndDate();
            if (b.getStatus().equals("Denied")||b.getStatus().equals("Cancelled"))
            {
               
            }
            else
            {
                if (newStartDate.equals(oldStartDate)) {
                legal = false;
            }
            if (oldEndDate.equals(newEndDate)) {
                legal = false;
            }
            if (newStartDate.after(oldStartDate) && newEndDate.before(oldEndDate)) {
                legal = false;
            }

            if (newStartDate.before(oldStartDate) && newEndDate.after(oldEndDate)) {
                legal = false;
            }

            if (newStartDate.after(oldStartDate) && newStartDate.before(oldEndDate) && newEndDate.after(oldEndDate)) {
                legal = false;
            }

            if (newStartDate.before(oldStartDate) && newEndDate.after(oldStartDate) && newEndDate.before(oldEndDate)) {
                legal = false;
            }
             
                
            }
            

        }
        return legal;
    }

    @Override
    public void extendBooking(BookingDTO vehicleID, int daysOfRental) {
        Date dayOne = vehicleID.getEndDate();
        dayOne.setDate(dayOne.getDate() + daysOfRental);
        Query q = em.createNamedQuery("Bookings.pushRent");
        q.setParameter(1, dayOne);
        q.setParameter(2, vehicleID.getBookingID());
        q.executeUpdate();
    }

}
