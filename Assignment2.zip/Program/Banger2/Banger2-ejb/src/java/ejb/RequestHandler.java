/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.RequestDTO;
import entity3.Collectrequests;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.rowset.serial.SerialBlob;

/**
 *
 * @author x74po
 */
@Stateless
public class RequestHandler implements RequestHandlerRemote {

    

    @PersistenceContext(unitName = "Banger2-ejbPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }
    
    @Override
    public void setCheckedStatue(boolean b, RequestDTO req) {
           Boolean banStatus = true;
            Query q = em.createNamedQuery("Collectrequests.setChecked");
            q.setParameter(1, b);
            q.setParameter(2, req.getRequestID());
            q.executeUpdate();
    }

    @Override
    public void registerCollection(RequestDTO requestDTO) {
        try{
            SerialBlob license = new SerialBlob(requestDTO.getLicenseScan());
            SerialBlob addID = new SerialBlob(requestDTO.getAdditionalID());
            Collectrequests c = new Collectrequests();
            c.setBookingid(requestDTO.getBookingID());
            c.setFname(requestDTO.getfName());
            c.setLname(requestDTO.getlName());
            c.setLicenseno(requestDTO.getLicenseNo());
            c.setLicensescan(license);
            c.setAdditionalid(addID);
            c.setChecked(false);
            c.setIllegal(false);
            persist(c);
            
        }
        catch (Exception e) {
            throw new EJBException("Error while creating a Request: ", e);
        }
    }
    
    @Override
    public Collection<RequestDTO> getAllRequestCollections() {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Collectrequests> list = em.createNamedQuery("Collectrequests.findAll").getResultList();
        Collection<RequestDTO> bookingList = new ArrayList<>(list.size());
       
        try
        {
            for (Collectrequests c : list) {
            byte[] arrayA = (((SerialBlob)c.getLicensescan()).getBytes(1, (int)((SerialBlob)c.getLicensescan()).length()));
            byte[] arrayB = (((SerialBlob)c.getAdditionalid()).getBytes(1, (int)((SerialBlob)c.getAdditionalid()).length()));
            RequestDTO singleDTO = new RequestDTO(c.getRequestid(), c.getBookingid(), c.getFname(), c.getLname(), c.getLicenseno(), arrayA , arrayB, c.getChecked(), c.getIllegal());
            bookingList.add(singleDTO);
        }
        }
        catch (Exception e)
        {
            
        }
        return bookingList;
    }
}
