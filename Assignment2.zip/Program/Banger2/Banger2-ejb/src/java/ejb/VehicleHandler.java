/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.VehicleDTO;
import entity3.Vehicle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author x74po
 */
@Stateless
public class VehicleHandler implements VehicleHandlerRemote {

    @PersistenceContext(unitName = "Banger2-ejbPU")
    private EntityManager em;

    public void persist(Object object)
    {
        em.persist(object);
    }

    
    @Override
    public Collection<VehicleDTO> getAllVehicles() {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Vehicle> list = em.createNamedQuery("Vehicle.findAll").getResultList();
        Collection<VehicleDTO> equipList = new ArrayList<>(list.size());
        for (Vehicle v : list)
        {
            VehicleDTO vehicleSingle = new VehicleDTO(v.getVehicleid(), v.getName(), v.getCostperday());
            equipList.add(vehicleSingle);
        }
        return equipList;
    }
    
    private java.sql.Timestamp dateToSQL(java.util.Date theDate){
        return new java.sql.Timestamp(theDate.getTime());
        
    }
    private java.util.Date SQLtoDate(java.sql.Timestamp theDate){
        return new java.util.Date(theDate.getTime());
        
    }

    

    @Override
    public Collection<VehicleDTO> getAllAvailableVehicles() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public VehicleDTO getVehicle(int vehicleID) {
        Vehicle theVehicle = getVehicleAsVehicleObj(vehicleID);
        VehicleDTO vehicleDTOObj = new VehicleDTO(theVehicle.getVehicleid(), theVehicle.getName(), theVehicle.getCostperday());
        return vehicleDTOObj;
    }
    
    public Vehicle getVehicleAsVehicleObj(int vehicleID)
    {
        Object vehicleObj = em.createNamedQuery("Vehicle.findByVehicleid").setParameter("vehicleid", vehicleID).getSingleResult();
        return (Vehicle) vehicleObj;
    }
    
    @Override
    public void changePrice(int vehicleID, double price) {
        Boolean banStatus = true;
        Query q = em.createNamedQuery("Vehicle.changePrice");
        q.setParameter(1, price);
        q.setParameter(2, vehicleID);
        q.executeUpdate();
    }

}
