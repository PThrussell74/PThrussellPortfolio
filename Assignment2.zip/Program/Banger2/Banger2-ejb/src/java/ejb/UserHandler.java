/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.MemberDTO;
import entity3.Users;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
/**
 *
 * @author x74po
 */
@Stateless
public class UserHandler implements AdminHandlerRemote {

    @PersistenceContext(unitName = "Banger2-ejbPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    private java.sql.Timestamp dateToSQL(java.util.Date theDate) {
        return new java.sql.Timestamp(theDate.getTime());

    }

    private java.util.Date SQLtoDate(java.sql.Timestamp theDate) {
        return new java.util.Date(theDate.getTime());

    }

    @Override
    public Collection<MemberDTO> getAllUsers() {
        em.getEntityManagerFactory().getCache().evictAll();
        List<Users> list = em.createNamedQuery("Users.findAll").getResultList();
        Collection<MemberDTO> theList = new ArrayList<>(list.size());
        for (Users u : list) {
            MemberDTO entrySingle = new MemberDTO(u.getUserid(), u.getName(), u.getEmail(), u.getPassword(), u.getBanned(), u.getIsadmin(), u.getDob());
            theList.add(entrySingle);
        }
        return theList;
    }

    @Override
    public Collection<MemberDTO> getAllAvailableUsers() {
        //Unused
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteUser(int id) {
        try {
            Users u = em.find(Users.class, id);
            em.remove(u);
        } catch (Exception e) {
            throw new EJBException("The user could not be deleted", e);
        }
    }

    @Override
    public void banUser(int userID) {
        Boolean banStatus = true;
        Query q = em.createNamedQuery("Users.setBanned");
        q.setParameter(1, banStatus);
        q.setParameter(2, userID);
        q.executeUpdate();
    }

    @Override
    public void register(MemberDTO member) {
        Users u = new Users();
        u.setName(member.getName());
        u.setEmail(member.getEmail());
        u.setPassword(member.getPassword());
        u.setIsadmin(member.isIsAdmin());
        u.setDob(member.getDOB());
        u.setBanned(false);
        try {
            persist(u);
        } catch (Exception e) {
            throw new EJBException("Error while creating a Member: ", e);
        }
    }

    @Override
    public MemberDTO loginUser(String email, String password) {
        MemberDTO direct = null;
        Collection<MemberDTO> everyone = getAllUsers();
        for (MemberDTO u : everyone) {
            if (u.getEmail().equals(email) && u.getPassword().equals(password)) {
                direct = u;
            }
        }
        return direct;

    }

    @Override
    public void ban(int theMember) {
        Boolean banStatus = true;
        Query q = em.createNamedQuery("Users.setBanned");
        q.setParameter(1, banStatus);
        q.setParameter(2, theMember);
        q.executeUpdate();
    }

    @Override
    public MemberDTO getMemberByID(MemberDTO loggedMember) {
        Users theUser = getMemberasMemberObj(loggedMember);
        MemberDTO memberToReturn = new MemberDTO(theUser.getUserid(),theUser.getName(),theUser.getEmail(),theUser.getPassword(),theUser.getBanned(),theUser.getIsadmin(),theUser.getDob());
        return memberToReturn;
    }
    
    public Users getMemberasMemberObj(MemberDTO theDTO)
    {
        Object memberObj = em.createNamedQuery("Users.findByUserid").setParameter("userid", theDTO.getUserID()).getSingleResult();
        return (Users) memberObj;
    }

}
