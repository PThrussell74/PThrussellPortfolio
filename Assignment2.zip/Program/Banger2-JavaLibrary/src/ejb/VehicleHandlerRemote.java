package ejb;

import dto.BookingDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.Remote;

@Remote
public interface VehicleHandlerRemote
{

    Collection<VehicleDTO> getAllVehicles();
    
    Collection<VehicleDTO> getAllAvailableVehicles();
    
    VehicleDTO getVehicle(int vehicleID);
    
    void changePrice(int vehicleID, double price);

}
