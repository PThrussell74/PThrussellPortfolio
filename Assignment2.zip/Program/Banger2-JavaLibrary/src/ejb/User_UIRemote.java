/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.Remote;

/**
 *
 * @author x74po
 */
@Remote
public interface User_UIRemote {

    MemberDTO loginUser(String email, String password);

    void logoutUser();

    Collection<VehicleDTO> getAllVehicles();
    Collection<VehicleDTO> getAllAvailableVehicles();

    VehicleDTO getVehicle(int vehicleID);

    void registerUser(MemberDTO member);

    MemberDTO getMemberByID(MemberDTO loggedMember);
    
    void changePrice(int vehicleID, double newPrice);

    void registerCollection(RequestDTO requestDTO);
    
    
    

}
