package ejb;

import dto.BookingDTO;
import dto.MemberDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.Remote;

@Remote
public interface BookingHandlerRemote {

    void createBooking(BookingDTO booking);
    
    Collection<BookingDTO> getAllBookings();
    
    Collection<BookingDTO> getAllMyBookings(MemberDTO userDTO);

    BookingDTO getBookingByID(int bookingID);

    void updateStatus(BookingDTO tempBooking);

    void setBookingStatus(BookingDTO tempBooking, String theStatus);
    
    Boolean checkBookingCollision(BookingDTO theDTO, int carID);
    
    Collection<BookingDTO> getAllBookingsViaCarID(int ID);

    void extendBooking(BookingDTO vehicleID, int daysOfRental);

}
