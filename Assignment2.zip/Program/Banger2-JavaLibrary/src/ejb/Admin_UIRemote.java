/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.MemberDTO;
import dto.RequestDTO;
import java.util.Collection;
import javax.ejb.Remote;

/**
 *
 * @author x74po
 */
@Remote
public interface Admin_UIRemote {

    
    void removeUser(int userID);
    
    void banUser(int userID);

    void viewMember(int memberID);

    Collection<MemberDTO> getAllUsers();
    Collection<MemberDTO> getAllAvailableUsers();

    void receiveVehicle(int vehicleID);

    void businessMethod();

    Collection<RequestDTO> getAllRequests();
}
