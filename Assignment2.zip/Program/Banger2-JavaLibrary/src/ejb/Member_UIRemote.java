/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import dto.BookingDTO;
import dto.MemberDTO;
import dto.RequestDTO;
import dto.VehicleDTO;
import java.util.Collection;
import javax.ejb.Remote;

/**
 *
 * @author x74po
 */
@Remote
public interface Member_UIRemote {

    void extendVehicleRent(BookingDTO vehicleID, int daysOfRental);

    void createBooking(BookingDTO booking);
    
    Collection<BookingDTO> getAllBookings();

    Collection<BookingDTO> getAllMyBookings(MemberDTO theDTO);
    
    BookingDTO getBookingByID(int userID);

    void updateStatus(BookingDTO tempBooking);
    
    void setBookingStatus(BookingDTO tempBooking, String theStatus);

    Boolean checkBookingCollision(BookingDTO theDTO, int carID);

    void ban(int theMember);

    Collection<BookingDTO> getBookingsByVehicleID(int ID);

    void collectVehicle(int vehicleID, int userID);

    void rentEquipment(int equipmentID, int userID, double daysOfRental);

    void collectEquipment(int equipmentID, int userID);

    void rentVehicle(int vehicleID, int userID, double daysOfRental);

    void returnVehicle(int vehicleID);

    void returnEquipment(int equipmentID);

    Collection<VehicleDTO> getVehicleCollection();

    void setCheckedStatue(boolean b, RequestDTO req);
    


}
