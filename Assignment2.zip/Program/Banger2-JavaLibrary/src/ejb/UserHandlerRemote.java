package ejb;

import dto.MemberDTO;
import java.util.Collection;
import javax.ejb.Remote;

@Remote
public interface UserHandlerRemote {

    public void ban(MemberDTO theMember);

}
