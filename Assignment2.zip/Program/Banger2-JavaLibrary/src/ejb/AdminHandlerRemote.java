package ejb;

import dto.MemberDTO;
import java.util.Collection;
import javax.ejb.Remote;


@Remote
public interface AdminHandlerRemote
{

    Collection<MemberDTO> getAllUsers();
    
    Collection<MemberDTO> getAllAvailableUsers();
    
    void deleteUser(int userID);
    
    void banUser(int userID);
    
    void register(MemberDTO member);
    
    MemberDTO loginUser(String email, String password);

    void ban(int theMember);

    MemberDTO getMemberByID(MemberDTO loggedMember);
}
