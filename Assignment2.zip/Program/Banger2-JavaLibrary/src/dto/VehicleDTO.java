/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;

/**
 *
 * @author x74po
 */
public class VehicleDTO implements Serializable {

    private final int vehicleID;
    private final String name;
    private final Double costPerDay;

    public VehicleDTO(int vehicleID, String name, Double costPerDay) {
        this.vehicleID = vehicleID;
        this.name = name;
        this.costPerDay = costPerDay;
    }

    @Override
    public boolean equals(Object obj) {
        return obj != null
                && obj instanceof VehicleDTO
                && ((VehicleDTO) obj).getVehicleID() == this.vehicleID;
    }

    public int getVehicleID() {
        return vehicleID;
    }

    public Double getCostPerDay() {
        return costPerDay;
    }

    public String getName() {
        return name;
    }

    @Override
    public int hashCode() {
        return this.vehicleID;
    }

    @Override
    public String toString() {
        return name;
    }
}
