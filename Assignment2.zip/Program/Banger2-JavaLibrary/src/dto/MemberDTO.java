/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author x74po
 */
public class MemberDTO implements Serializable {

    private final int userID;
    private final String name;
    private final String email;
    private final String password;
    private boolean banned;
    private final boolean isAdmin;
    private final Date DOB;

    public MemberDTO(int userID, String name, String email, String password, boolean banned, boolean isAdmin, Date DOB) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.banned = banned;
        this.isAdmin = isAdmin;
        this.DOB = DOB;
    }

    public int getUserID() {
        return userID;
    }
    

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public boolean isBanned() {
        return banned;
    }

    public boolean isIsAdmin() {
        return isAdmin;
    }

    public void setBanned(boolean banned) {
        this.banned = banned;
    }

    public Date getDOB() {
        return DOB;
    }
    
    @Override
    public boolean equals(Object obj) {
        return obj != null
                && obj instanceof MemberDTO
                && ((MemberDTO) obj).getUserID() == this.userID;
    }

    @Override
    public int hashCode() {
        return this.userID;
    }

}
