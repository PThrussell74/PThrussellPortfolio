/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

/**
 *
 * @author x74po
 */
public class RequestDTO implements Serializable{
    
    private int requestID;
    private int bookingID;
    private String fName;
    private String lName;
    private String licenseNo;
    private byte[] licenseScan;
    private byte[] additionalID;
    private Boolean checked;
    private Boolean illegal;
    private String name;

    public RequestDTO(int requestID, int bookingID, String fName, String lName, String licenseNo, byte[] licenseScan, byte[] additionalID, Boolean checked, Boolean illegal) {
        this.requestID = requestID;
        this.bookingID = bookingID;
        this.fName = fName;
        this.lName = lName;
        this.licenseNo = licenseNo;
        this.licenseScan = licenseScan;
        this.additionalID = additionalID;
        this.checked = checked;
        this.illegal = illegal;
        this.name = fName+" "+lName;
    }
    
    public RequestDTO()
    {
        
    }

    public int getRequestID() {
        return requestID;
    }

    public int getBookingID() {
        return bookingID;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public byte[] getLicenseScan() {
        return licenseScan;
    }

    public byte[] getAdditionalID() {
        return additionalID;
    }
    
    

    public Boolean getChecked() {
        return checked;
    }
    
    public String getName() {
        return fName+ "-" + lName;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public Boolean getIllegal() {
        return illegal;
    }

    public void setIllegal(Boolean illegal) {
        this.illegal = illegal;
    }

    public void setRequestID(int requestID) {
        this.requestID = requestID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }

    public void setLicenseScan(byte[] licenseScan) {
        this.licenseScan = licenseScan;
    }

    public void setAdditionalID(byte[] additionalID) {
        this.additionalID = additionalID;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.requestID;
        hash = 29 * hash + this.bookingID;
        hash = 29 * hash + Objects.hashCode(this.fName);
        hash = 29 * hash + Objects.hashCode(this.lName);
        hash = 29 * hash + Objects.hashCode(this.licenseNo);
        hash = 29 * hash + Arrays.hashCode(this.licenseScan);
        hash = 29 * hash + Arrays.hashCode(this.additionalID);
        hash = 29 * hash + Objects.hashCode(this.checked);
        hash = 29 * hash + Objects.hashCode(this.illegal);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RequestDTO other = (RequestDTO) obj;
        if (this.requestID != other.requestID) {
            return false;
        }
        if (this.bookingID != other.bookingID) {
            return false;
        }
        if (this.licenseNo != other.licenseNo) {
            return false;
        }
        if (!Objects.equals(this.fName, other.fName)) {
            return false;
        }
        if (!Objects.equals(this.lName, other.lName)) {
            return false;
        }
        if (!Arrays.equals(this.licenseScan, other.licenseScan)) {
            return false;
        }
        if (!Arrays.equals(this.additionalID, other.additionalID)) {
            return false;
        }
        if (!Objects.equals(this.checked, other.checked)) {
            return false;
        }
        if (!Objects.equals(this.illegal, other.illegal)) {
            return false;
        }
        return true;
    }
    
    
    
    
    
}
