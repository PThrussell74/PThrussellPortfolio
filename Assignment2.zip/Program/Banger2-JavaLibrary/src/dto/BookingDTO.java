/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author x74po
 */
public class BookingDTO implements Serializable {

    private final int bookingID;
    private final int userID;
    private final Date startDate;
    private final Date endDate;
    private final int carID;
    private final Boolean satNav;
    private final Boolean carSeat;
    private final Boolean wineChiller;
    private String status;

    public BookingDTO(int bookingID, int userID, Date startDate, Date endDate, int carID, Boolean satNav, Boolean carSeat, Boolean wineChiller, String status) {
        this.bookingID = bookingID;
        this.userID = userID;
        this.startDate = startDate;
        this.endDate = endDate;
        this.carID = carID;
        this.satNav = satNav;
        this.carSeat = carSeat;
        this.wineChiller = wineChiller;
        this.status = status;
    }

    public int getBookingID() {
        return bookingID;
    }
    
    public BookingDTO getSelf()
    {
        return this;
    }

    public int getUserID() {
        return userID;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public int getCarID() {
        return carID;
    }

    public Boolean getSatNav() {
        return satNav;
    }

    public Boolean getCarSeat() {
        return carSeat;
    }

    public Boolean getWineChiller() {
        return wineChiller;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    

    @Override
    public boolean equals(Object obj) {
        return obj != null
                && obj instanceof BookingDTO
                && ((BookingDTO) obj).getBookingID() == this.bookingID;
    }

    @Override
    public int hashCode() {
        return this.bookingID;
    }

    @Override
    public String toString() {
        return bookingID + " - User ID:" + userID+ " - Status:" + status;
    }
    
    

}
