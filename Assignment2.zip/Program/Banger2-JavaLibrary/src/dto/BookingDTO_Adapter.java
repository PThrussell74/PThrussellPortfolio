/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author x74po
 */
public class BookingDTO_Adapter extends BookingDTO {

    public BookingDTO_Adapter(int bookingID, int userID, Date startDate, Date endDate, int carID, Boolean satNav, Boolean carSeat, Boolean wineChiller, String status) {
        super(bookingID, userID, startDate, endDate, carID, satNav, carSeat, wineChiller, status);
    }

    public String getAndChangeStatus() {
        String status = getStatus();
        Date startDate = getStartDate();
        Date endDate = getEndDate();
        if (status.equals("Not Ready") && checkTime(startDate, endDate)) {
            setStatus("Ready");
        }
        return status;
    }

    public boolean checkTime(Date startDate, Date endDate) {
        Boolean ready = false;
        Date date = new Date();
        date.getTime();
        if (date.before(endDate) && date.after(startDate)) 
        {
            ready = true;
        }
        return ready;
    }

}
