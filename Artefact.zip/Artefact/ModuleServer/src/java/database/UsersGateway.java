/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import dto.UsersDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class UsersGateway {

    private static final String GET_ALL_USERS = "SELECT * FROM USERS";

    private static final String ADD_USER
            = "INSERT INTO USERS (EMAIL, PASSWORD) "
            + "VALUES (?, ?)";

    public ArrayList<UsersDTO> getAllUsers() {
        ArrayList<UsersDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement(GET_ALL_USERS);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UsersDTO user = new UsersDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));
                list.add(user);
            }
            conn.close();
        } catch (NullPointerException npe) {
            System.err.println("No connection available");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public ArrayList<UsersDTO> getUserByID(int ID) {

        ArrayList<UsersDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM USERS WHERE USERID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UsersDTO user = new UsersDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));
                list.add(user);
            }
            conn.close();
        } catch (NullPointerException npe) {
            System.err.println("No connection available");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public Object addUser(String username, String password) 
    {
        String un="Success";
        
        Connection conn = DB_Manager.getConnection();
            try {
                PreparedStatement stmt = conn.prepareStatement(ADD_USER);
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.executeUpdate();

                conn.close();
            } catch (NullPointerException npe) {
                System.err.println("No connection available");
            } catch (SQLException sqle) {
                System.err.println(sqle.getMessage());
            }
        return un;
    }

    public UsersDTO loginUserByCredentialsCommand(String username, String password) {
        UsersDTO user = new UsersDTO(-1, "null", "null");
        Connection conn = DB_Manager.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM USERS WHERE EMAIL = ? AND PASSWORD = ?");
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                user = new UsersDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));

            }
            conn.close();
        } catch (NullPointerException npe) {
            System.err.println("No connection available");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
        return user;
    }
}
