/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import dto.ReadingsDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class ReadingsGateway {
    
    private static final String GET_ALL_READINGS = "SELECT * FROM READINGS";
    
        private static final String ADD_READING
            = "INSERT INTO READINGS (SENSORID, DATE, SOILMOISTURE, AIRMOISTURE, WATERED) "
            + "VALUES (?, ?, ?, ?, ?)";
    
    public ArrayList<ReadingsDTO> getAllReadings()
    {
        ArrayList<ReadingsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(GET_ALL_READINGS);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                ReadingsDTO sensor = new ReadingsDTO(
                        rs.getInt("READINGID"),
                        rs.getInt("SENSORID"),
                        rs.getTimestamp("DATE"),
                        rs.getInt("SOILMOISTURE"),
                        rs.getInt("AIRMOISTURE"),
                        rs.getString("WATERED"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public ArrayList<ReadingsDTO> getReadingByID(int ID) {
        
        ArrayList<ReadingsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM READINGS WHERE READINGID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                ReadingsDTO sensor = new ReadingsDTO(
                        rs.getInt("READINGID"),
                        rs.getInt("SENSORID"),
                        rs.getTimestamp("DATE"),
                        rs.getInt("SOILMOISTURE"),
                        rs.getInt("AIRMOISTURE"),
                        rs.getString("WATERED"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public ArrayList<ReadingsDTO> getReadingsBySensorID(int ID) {
        
        ArrayList<ReadingsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM READINGS WHERE SENSORID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                ReadingsDTO sensor = new ReadingsDTO(
                        rs.getInt("READINGID"),
                        rs.getInt("SENSORID"),
                        rs.getTimestamp("DATE"),
                        rs.getInt("SOILMOISTURE"),
                        rs.getInt("AIRMOISTURE"),
                        rs.getString("WATERED"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public void addReading (int SENSORID, int SOILMOISTURE, int AIRMOISTURE, String WATERED)
    {
        Connection conn = DB_Manager.getConnection();
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            
            java.util.Date date = java.util.Calendar.getInstance().getTime();

            
            PreparedStatement stmt = conn.prepareStatement(ADD_READING);
            stmt.setInt(1, SENSORID);
            stmt.setTimestamp(2, new Timestamp(date.getTime()));
            stmt.setInt(3, SOILMOISTURE);
            stmt.setInt(4, AIRMOISTURE);
            stmt.setString(5, WATERED);
            stmt.executeUpdate();
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
    }


}