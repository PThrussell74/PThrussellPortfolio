/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import dto.AdminsDTO;
import dto.UsersDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class AdminsGateway {
    
    private static final String GET_ALL_ADMINS = "SELECT * FROM ADMINS";
    
        private static final String ADD_ADMIN
            = "INSERT INTO ADMINS (EMAIL, PASSWORD) "
            + "VALUES (?, ?)";
    
    public ArrayList<AdminsDTO> getAllAdmins()
    {
        ArrayList<AdminsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(GET_ALL_ADMINS);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                AdminsDTO admin = new AdminsDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));
                list.add(admin);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public ArrayList<AdminsDTO> getAdminByID(int ID) {
        
        ArrayList<AdminsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ADMIN WHERE ADMINID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                AdminsDTO admin = new AdminsDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));
                list.add(admin);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public void addAdmin (String username, String password)
    {
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(ADD_ADMIN);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.executeUpdate();
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
    }

    public Object loginAdminByCredentialsCommand(String username, String password) {
    AdminsDTO admin = new AdminsDTO(-1, "null", "null");
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ADMINS WHERE EMAIL = ? AND PASSWORD = ?");
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                admin = new AdminsDTO(
                        rs.getInt("USERID"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"));
                
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return admin;
    }
}