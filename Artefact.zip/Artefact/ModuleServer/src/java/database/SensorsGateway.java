/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import dto.SensorsDTO;
import dto.UsersDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class SensorsGateway {
    
    private static final String GET_ALL_SENSORS = "SELECT * FROM SENSORS";
    private static final String UPDATE_SOIL_THRESHOLD = "UPDATE SENSORS SET SOILTHRESHOLD = ? WHERE SENSORID = ?";
    private static final String UPDATE_AIR_THRESHOLD = "UPDATE SENSORS SET AIRTHRESHOLD = ? WHERE SENSORID = ?";
    
        private static final String ADD_SENSOR
            = "INSERT INTO SENSORS (OWNERID) "
            + "VALUES (?)";
    
    public ArrayList<SensorsDTO> getAllSensors()
    {
        ArrayList<SensorsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(GET_ALL_SENSORS);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                SensorsDTO sensor = new SensorsDTO(
                        rs.getInt("SENSORID"),
                        rs.getInt("OWNERID"),
                        rs.getInt("AIRTHRESHOLD"),
                        rs.getInt("SOILTHRESHOLD"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public ArrayList<SensorsDTO> getSensorsByID(int ID) {
        
        ArrayList<SensorsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM SENSORS WHERE SENSORID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                SensorsDTO sensor = new SensorsDTO(
                        rs.getInt("SENSORID"),
                        rs.getInt("OWNERID"),
                        rs.getInt("AIRTHRESHOLD"),
                        rs.getInt("SOILTHRESHOLD"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public String updateSoilMoistureThreshold(int ID, int value) {
        
        ArrayList<SensorsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(UPDATE_SOIL_THRESHOLD);
            stmt.setInt(1, value);
            stmt.setInt(2, ID);
            int rs = stmt.executeUpdate();
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return "OK";
    }
    
    public ArrayList<SensorsDTO> getSensorsByUserID(int ID) {
        
        ArrayList<SensorsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM SENSORS WHERE OWNERID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                SensorsDTO sensor = new SensorsDTO(
                        rs.getInt("SENSORID"),
                        rs.getInt("OWNERID"),
                        rs.getInt("AIRTHRESHOLD"),
                        rs.getInt("SOILTHRESHOLD"));
                list.add(sensor);
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public void addSensor (int userID)
    {
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(ADD_SENSOR);
            stmt.setInt(1, userID);
            stmt.executeUpdate();
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
    }
    
    public ArrayList<Integer> getSensorAirHumidThresholdByID(int ID) {
        
        Connection conn = DB_Manager.getConnection();
        ArrayList<Integer> list = new ArrayList<>();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM SENSORS WHERE SENSORID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                list.add(rs.getInt("AIRTHRESHOLD"));
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }
    
    public ArrayList<Integer> getSensorSoilHumidThresholdByID(int ID) {
        
        Connection conn = DB_Manager.getConnection();
        ArrayList<Integer> list = new ArrayList<>();
        try
        {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM SENSORS WHERE SENSORID = ?");
            stmt.setInt(1, ID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                list.add(rs.getInt("SOILTHRESHOLD"));
            }
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
        return list;
    }

    public void updateAirMoistureThreshold(int ID, int value) {
        ArrayList<SensorsDTO> list = new ArrayList<>();
        Connection conn = DB_Manager.getConnection();
        try
        {
            PreparedStatement stmt = conn.prepareStatement(UPDATE_AIR_THRESHOLD);
            stmt.setInt(1, value);
            stmt.setInt(2, ID);
            int rs = stmt.executeUpdate();
            conn.close();
        }
        catch (NullPointerException npe)
        {
            System.err.println("No connection available");
        }
        catch (SQLException sqle)
        {
            System.err.println(sqle.getMessage());
        }
    }
}