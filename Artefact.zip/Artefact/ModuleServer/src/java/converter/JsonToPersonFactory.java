/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package converter;

import com.google.gson.Gson;
import dto.AdminsDTO;
import dto.UsersDTO;

/**
 *
 * @author x74po
 */
public class JsonToPersonFactory {
    
    private static final JsonToPersonFactory uniqueInstance = new JsonToPersonFactory();
    
    private JsonToPersonFactory() {

    }
    
    public static JsonToPersonFactory getInstance() {
        return uniqueInstance;
    }

    public UsersDTO convertUsersDTO(String toAdd)
    {
        Gson gson = new Gson();
        UsersDTO user = gson.fromJson(toAdd, UsersDTO.class);
        return new UsersDTO(0, user.getEmail(), user.getPassword());
    }
    

    public AdminsDTO convertAdminsDTO(String toAdd)
    {
        Gson gson = new Gson();
        AdminsDTO user = gson.fromJson(toAdd, AdminsDTO.class);
        return new AdminsDTO(0, user.getEmail(), user.getPassword());
    }
    
}
