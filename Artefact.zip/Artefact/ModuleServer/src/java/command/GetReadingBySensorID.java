/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.ReadingsManager;

/**
 *
 * @author x74po
 */
public class GetReadingBySensorID implements Command {

    private final ReadingsManager manager;
    private final int sensorID;

    public GetReadingBySensorID(int sensorID) {
        this.manager = new ReadingsManager();
        this.sensorID = sensorID;
    }

    @Override
    public Object execute() {
        return manager.getReadingsBySensorID(sensorID);
    }

    
}
