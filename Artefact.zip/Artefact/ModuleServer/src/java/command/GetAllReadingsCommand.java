/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.ReadingsManager;

/**
 *
 * @author x74po
 */
public class GetAllReadingsCommand implements Command {

    private final ReadingsManager manager;

    public GetAllReadingsCommand()
    {
        this.manager = new ReadingsManager();
    }
    
    @Override
    public Object execute()
    {
        return manager.getAllReadings();
    }
    
}
