/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.SensorsManager;

/**
 *
 * @author x74po
 */
public class GetSensorByIDCommand implements Command {

    private final SensorsManager manager;
    private final int sensorID;

    public GetSensorByIDCommand(int userID) {
        this.manager = new SensorsManager();
        this.sensorID = userID;
    }

    @Override
    public Object execute() {
        return manager.getSensorByID(sensorID);
    }

}
