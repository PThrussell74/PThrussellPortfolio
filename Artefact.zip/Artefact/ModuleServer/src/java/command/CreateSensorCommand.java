/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.SensorsManager;

/**
 *
 * @author x74po
 */
public class CreateSensorCommand implements Command {

    private final SensorsManager manager;
    private final int userID;

    public CreateSensorCommand(int userID)
    {
        this.manager = new SensorsManager();
        this.userID = userID;
    }
    
    @Override
    public Object execute()
    {
        manager.createSensor(userID);
        return userID+"";
    }
    
    
}
