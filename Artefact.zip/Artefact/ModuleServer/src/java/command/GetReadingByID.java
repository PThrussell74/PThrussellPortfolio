/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.ReadingsManager;

/**
 *
 * @author x74po
 */
public class GetReadingByID implements Command {

    private final ReadingsManager manager;
    private final int sensorID;

    public GetReadingByID(int userID) {
        this.manager = new ReadingsManager();
        this.sensorID = userID;
    }

    @Override
    public Object execute() {
        return manager.getReadingsByID(sensorID);
    }

    
}
