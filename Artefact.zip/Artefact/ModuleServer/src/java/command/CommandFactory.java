/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;
/**
 *
 * @author x74po
 */
public class CommandFactory {
    public static final int GET_ALL_USERS = 1;
    public static final int GET_USER_BY_ID = 2;
    public static final int ADD_USER = 3;
    public static final int LOGIN_USER_BY_CREDENTIALS = 4;
    
    public static final int GET_ALL_ADMINS = 11;
    public static final int GET_ADMIN_BY_ID = 12;
    public static final int ADD_ADMIN = 13;
    public static final int LOGIN_ADMIN_BY_CREDENTIALS = 14;
    
    public static final int GET_ALL_SENSORS = 21;
    public static final int GET_SENSOR_BY_ID = 22;
    public static final int GET_SENSOR_BY_USERID = 23;
    public static final int ADD_SENSOR = 24;
    public static final int GET_SENSOR_AIR_HUMIDITY_BY_ID = 25;
    public static final int GET_SENSOR_SOIL_HUMIDITY_BY_ID = 26;
    public static final int UPDATESOILMOISTURETHRESHOLD = 27;
    public static final int UPDATEAIRMOISTURETHRESHOLD = 28;
    
    public static final int GET_ALL_READINGS = 31;
    public static final int GET_READING_BY_ID = 32;
    public static final int GET_READINGS_BY_SENSORID = 33;
    public static final int ADD_READING = 34;
    
    
    
    
    
    public static Command createCommand(int commandType)
    {
        switch(commandType)
        {
            case GET_ALL_USERS:
                return new GetAllUsersCommand();
            case GET_ALL_ADMINS:
                return new GetAllAdminsCommand();
            case GET_ALL_SENSORS:
                return new GetAllSensorsCommand();
            case GET_ALL_READINGS:
                return new GetAllReadingsCommand();
            default:
                return new NullCommand();
        }
    }
    
    public static Command createCommand(int commandType, int int1, int int2)
    {
        switch(commandType)
        {
            case UPDATESOILMOISTURETHRESHOLD:
                return new UpdateSoilThresholdCommand(int1, int2);
            case UPDATEAIRMOISTURETHRESHOLD:
                return new UpdateAirThresholdCommand(int1, int2);
            default:
                return new NullCommand();
        }
    }
   
    
    public static Command createCommand(int commandType, int ID)
    {
        switch(commandType)
            
        {
            case GET_USER_BY_ID:
                return new GetUserByIDCommand(ID);
            case GET_ADMIN_BY_ID:
                return new GetAdminByIDCommand(ID);
            case GET_SENSOR_BY_ID:
                return new GetSensorByIDCommand(ID);
            case GET_SENSOR_BY_USERID:
                return new GetSensorByUserIDCommand(ID);
            case GET_READING_BY_ID:
                return new GetReadingByID(ID);
            case GET_READINGS_BY_SENSORID:
                return new GetReadingBySensorID(ID);
            case GET_SENSOR_AIR_HUMIDITY_BY_ID:
                return new GetSensorAirHumidityByID(ID);
            case GET_SENSOR_SOIL_HUMIDITY_BY_ID:
                return new GetSensorSoilHumidityByID(ID);
                
                
            case ADD_SENSOR:
                return new CreateSensorCommand(ID);
            default:
                return new NullCommand();
        }
    }
    
    public static Command createCommand(int commandType, String str1, String str2)
    {
        switch(commandType)
            
        {
            case ADD_USER:
                return new CreateUserCommand(str1, str2);
            case ADD_ADMIN:
                return new CreateAdminCommand(str1, str2);
            case LOGIN_USER_BY_CREDENTIALS:
                return new LoginUserByCredentialsCommand(str1, str2);
            case LOGIN_ADMIN_BY_CREDENTIALS:
                return new LoginAdminByCredentialsCommand(str1, str2);
            default:
                return new NullCommand();
        }
    }
    
    public static Command createCommand(int commandType,int intA, int intB, int intC, String strA)
    {
        switch(commandType)
            
        {
            case ADD_READING:
                return new CreateReadingCommand(intA, intB, intC, strA);
            default:
                return new NullCommand();
        }
    }
    
}
