/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.SensorsManager;

/**
 *
 * @author x74po
 */
public class GetSensorAirHumidityByID implements Command {

    private final SensorsManager manager;
    private final int ID;
    
    public GetSensorAirHumidityByID(int ID) 
    {
        this.ID = ID;
        this.manager = new SensorsManager();
    }

    @Override
    public Object execute() 
    {
        return manager.getSensorAirHumidityByID(ID);
    }
    
}
