/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.SensorsManager;

/**
 *
 * @author x74po
 */
public class UpdateAirThresholdCommand implements Command {

    private final SensorsManager manager;
    private final int ID;
    private final int value;
    
    public UpdateAirThresholdCommand(int ID, int value) 
    {
        this.ID = ID;
        this.value = value;
        this.manager = new SensorsManager();
    }

    @Override
    public Object execute() 
    {
        manager.updateAirThresholdCommand(ID, value);
        return "OK";
    }
    
}
