/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import java.sql.Date;
import manager.ReadingsManager;

/**
 *
 * @author x74po
 */
public class CreateReadingCommand implements Command {

    private final ReadingsManager manager;
    private final int sensorID;
    private final int soil;
    private final int air;
    private final String watered;

    public CreateReadingCommand(int sensorID, int soil, int air, String watered) {
        this.manager = new ReadingsManager();
        this.sensorID = sensorID;
        this.soil = soil;
        this.air = air;
        this.watered = watered;
    }
    
    @Override
    public Object execute()
    {
        manager.createReading(sensorID, soil, air, watered);
        return sensorID;
    }
    
}
