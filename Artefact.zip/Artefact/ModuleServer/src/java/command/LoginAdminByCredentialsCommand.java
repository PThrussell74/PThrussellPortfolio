/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.AdminsManager;

/**
 *
 * @author x74po
 */
public class LoginAdminByCredentialsCommand implements Command {


    private final AdminsManager manager;
    private final String username;
    private final String password;
    
    public LoginAdminByCredentialsCommand(String username, String password) 
    {
        this.username = username;
        this.password = password;
        this.manager = new AdminsManager();
    }

    @Override
    public Object execute() 
    {
        return manager.loginAdminByCredentialsCommand(username, password);
    }
    
}
