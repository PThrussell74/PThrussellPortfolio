/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.AdminsManager;

/**
 *
 * @author x74po
 */
public class GetAdminByIDCommand implements Command {

    private final AdminsManager manager;
    private final int ID;
    
    public GetAdminByIDCommand(int ID) 
    {
        this.ID = ID;
        this.manager = new AdminsManager();
    }

    @Override
    public Object execute() 
    {
        return manager.getAdminByID(ID);
    }
    
}
