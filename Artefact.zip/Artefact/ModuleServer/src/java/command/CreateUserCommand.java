/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import manager.UsersManager;

/**
 *
 * @author x74po
 */
public class CreateUserCommand implements Command {

    private final UsersManager manager;
    private final String username;
    private final String password;

    public CreateUserCommand(String username, String password)
    {
        this.manager = new UsersManager();
        this.username = username;
        this.password = password;
    }
    
    @Override
    public Object execute()
    {
        
        return manager.createUser(username, password);
    }
    
}
