/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;

/**
 *
 * @author x74po
 */
public class SensorsDTO implements Serializable{
    private final int sensorID;
    private int ownerID;
    private int soilSensor;
    private int airSensor;
    private int airHumidThreshold;
    private int soilHumidThreshold;
    private int serving;
    private boolean dehimidifierStatus;

    public SensorsDTO(int sensorID) {
        this.sensorID = sensorID;
        ownerID = -1;
        soilSensor =1;
        airSensor = -1;
        airHumidThreshold = -1;
        soilHumidThreshold = -1;
        serving = -1;
        dehimidifierStatus = false;
    }

    public SensorsDTO(int sensorID, int ownerID) {
        this.sensorID = sensorID;
        this.ownerID = ownerID;
        soilSensor =1;
        airSensor = -1;
        airHumidThreshold = -1;
        soilHumidThreshold = -1;
        serving = -1;
        dehimidifierStatus = false;
    }
    
    public SensorsDTO(int sensorID, int ownerID, int airHumidThreshold, int soilHumidThreshold) {
        this.sensorID = sensorID;
        this.ownerID = ownerID;
        soilSensor =1;
        airSensor = -1;
        this.airHumidThreshold = airHumidThreshold;
        this.soilHumidThreshold = soilHumidThreshold;
        serving = -1;
        dehimidifierStatus = false;
    }

    public int getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(int ownerID) {
        this.ownerID = ownerID;
    }

    public int getSoilSensor() {
        return soilSensor;
    }

    public void setSoilSensor(int soilSensor) {
        this.soilSensor = soilSensor;
    }

    public int getAirSensor() {
        return airSensor;
    }

    public void setAirSensor(int airSensor) {
        this.airSensor = airSensor;
    }

    public int getAirHumidThreshold() {
        return airHumidThreshold;
    }

    public void setAirHumidThreshold(int airHumidThreshold) {
        this.airHumidThreshold = airHumidThreshold;
    }

    public int getSoilHumidThreshold() {
        return soilHumidThreshold;
    }

    public void setSoilHumidThreshold(int soilHumidThreshold) {
        this.soilHumidThreshold = soilHumidThreshold;
    }

    public int getServing() {
        return serving;
    }

    public void setServing(int serving) {
        this.serving = serving;
    }

    public boolean isDehimidifierStatus() {
        return dehimidifierStatus;
    }

    public void setDehimidifierStatus(boolean dehimidifierStatus) {
        this.dehimidifierStatus = dehimidifierStatus;
    }

    public int getSensorID() {
        return sensorID;
    }

}
