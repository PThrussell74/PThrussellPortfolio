/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author x74po
 */
public class ReadingsDTO implements Serializable{
    private final int readingID;
    private final int sensorID;
    private final Date date;
    private final int soilMoisture;
    private final int airMoisture;
    private final String watered;

    public ReadingsDTO(int readingID, int sensorID, Date date, int soilMoisture, int airMoisture, String watered) {
        this.readingID = readingID;
        this.sensorID = sensorID;
        this.date = date;
        this.soilMoisture = soilMoisture;
        this.airMoisture = airMoisture;
        this.watered = watered;
    }

    public int getReadingID() {
        return readingID;
    }

    public int getSensorID() {
        return sensorID;
    }

    public Date getDate() {
        return date;
    }

    public int getSoilMoisture() {
        return soilMoisture;
    }

    public int getAirMoisture() {
        return airMoisture;
    }

    public String getWatered() {
        return watered;
    }
    
    
    
    
}
