/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;

/**
 *
 * @author x74po
 */
public class UsersDTO implements Serializable{
    private final int userID;
    private final String email;
    private String password;

    public UsersDTO(int userID, String email, String password) {
        this.userID = userID;
        this.email = email;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUserID() {
        return userID;
    }

    public String getEmail() {
        return email;
    }
    
    public boolean matchingPassword(String input)
    {
        return password.equals(input);
    }
    
}
