/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import database.AdminsGateway;
import dto.AdminsDTO;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class AdminsManager {

    private final AdminsGateway gateway = new AdminsGateway();
    
    public ArrayList<AdminsDTO> getAllAdmins()
    {
        return gateway.getAllAdmins();
    }
    
    public ArrayList<AdminsDTO> getAdminByID(int ID)
    {
        return gateway.getAdminByID(ID);
    }
    
    public void createAdmin(String username, String password)
    {
        gateway.addAdmin(username, password);
    }

    public Object loginAdminByCredentialsCommand(String username, String password) {
        return gateway.loginAdminByCredentialsCommand(username, password);
    }
    
}
