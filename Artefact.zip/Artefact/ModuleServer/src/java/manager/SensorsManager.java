/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import database.SensorsGateway;
import dto.SensorsDTO;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class SensorsManager {

    private final SensorsGateway gateway = new SensorsGateway();
    
    public ArrayList<SensorsDTO> getAllSensors()
    {
        return gateway.getAllSensors();
    }
    
    public ArrayList<SensorsDTO> getSensorByID(int ID)
    {
        return gateway.getSensorsByID(ID);
    }
    
    public ArrayList<SensorsDTO> getSensorByUserID(int ID)
    {
        return gateway.getSensorsByUserID(ID);
    }
    
    public void createSensor(int userID)
    {
        gateway.addSensor(userID);
    }

    public Object getSensorAirHumidityByID(int ID) {
        return gateway.getSensorAirHumidThresholdByID(ID);
    }

    public Object getSensorSoilHumidityByID(int ID) {
        return gateway.getSensorSoilHumidThresholdByID(ID);
    }

    public void updateSoilThresholdCommand(int ID, int value) {
        gateway.updateSoilMoistureThreshold(ID, value);
    }

    public void updateAirThresholdCommand(int ID, int value) {
        gateway.updateAirMoistureThreshold(ID, value);
    }
    
}
