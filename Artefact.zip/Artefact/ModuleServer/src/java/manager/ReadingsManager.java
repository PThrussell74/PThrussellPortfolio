/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import database.ReadingsGateway;
import dto.ReadingsDTO;
import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class ReadingsManager {

    private final ReadingsGateway gateway = new ReadingsGateway();
    
    public ArrayList<ReadingsDTO> getAllReadings()
    {
        return gateway.getAllReadings();
    }
    
    public ArrayList<ReadingsDTO> getReadingsByID(int ID)
    {
        return gateway.getReadingByID(ID);
    }
    
    public void createReading(int ID, int soil, int air, String watered)
    {
        gateway.addReading(ID, soil, air, watered);
    }

    public ArrayList<ReadingsDTO> getReadingsBySensorID(int sensorID) {
        return gateway.getReadingsBySensorID(sensorID);
    }
    
}
