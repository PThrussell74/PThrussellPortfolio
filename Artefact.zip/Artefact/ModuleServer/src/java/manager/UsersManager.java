/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import database.UsersGateway;
import dto.UsersDTO;
import java.util.ArrayList;

/**
 *
 * @author x74po
 */
public class UsersManager {

    private final UsersGateway gateway = new UsersGateway();
    
    public ArrayList<UsersDTO> getAllUsers()
    {
        return gateway.getAllUsers();
    }
    
    public ArrayList<UsersDTO> getUserByID(int ID)
    {
        return gateway.getUserByID(ID);
    }
    
    public Object createUser(String username, String password)
    {
        return gateway.addUser(username, password);
    }

    public Object loginUserByCredentialsCommand(String username, String password) {
        return gateway.loginUserByCredentialsCommand(username, password);
    }
    
}
