/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservices;

import com.google.gson.Gson;
import command.CommandFactory;
import command.CreateAdminCommand;
import command.CreateReadingCommand;
import command.CreateSensorCommand;
import dto.AdminsDTO;
import dto.SensorsDTO;
import dto.UsersDTO;
import java.util.ArrayList;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author x74po
 */
@Path("myPath")
public class MyResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of MyResource
     */
    public MyResource() {
    }

    /**
     * Retrieves representation of an instance of webservices.MyResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String sayHello() {
        //TODO return proper representation object
        return "Hello Arduino";
    }
    
    @GET
    @Path("/GetTheTestMessage")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes("application/json")
    public String getTestInt() {
        return "Connected";
    }
    
    @GET
    @Path("/GetAllUsersCommand")
    @Produces("application/json")
    @Consumes("application/json")
    public String getAllUsers() {
        ArrayList<UsersDTO> getArray;

        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ALL_USERS)
                .execute();
        Gson gson = new Gson();
        String theString = gson.toJson(getArray);

        return theString;
    }
    
    @GET
    @Path("/getUserByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getUserByID(@PathParam("id") int id) {
        ArrayList<UsersDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_USER_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/checkUserExists/{username}/{password}")
    public Object checkUserExists(@PathParam("username") String email, @PathParam("password") String password)
    {
        Object returned;
        ArrayList<UsersDTO> getArray;
        boolean found = false;

        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ALL_USERS)
                .execute();
        
        for (UsersDTO user : getArray)
        {
            if (user.getEmail().equals(email))
            {
                found = true;
            }
        }
        
        if (found)
        {
            return "exist";
        }
        else
        {
            return createUser(email, password);
        }
        
    }
    

    public Object createUser(String email, String password)
    {
        Object user;
        user = CommandFactory
                .createCommand(
                        CommandFactory.ADD_USER, email, password)
                .execute();
        return "created";
        
    }
    
    @GET
    @Path("/loginUser/{username}/{password}")
    public Object loginUser(@PathParam("username") String email, @PathParam("password") String password)
    {
        Object user;
        user = CommandFactory
                .createCommand(
                        CommandFactory.LOGIN_USER_BY_CREDENTIALS, email, password)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(user);
        
        return user;
    }
    
    @GET
    @Path("/loginAdmin/{username}/{password}")
    public Object loginAdmin(@PathParam("username") String email, @PathParam("password") String password)
    {
        Object user;
        user = CommandFactory
                .createCommand(
                        CommandFactory.LOGIN_ADMIN_BY_CREDENTIALS, email, password)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(user);
        
        return user;
    }
    
    @GET
    @Path("/createSensor/{userID}")
    public String createSensor(@PathParam("userID") int userID)
    {
        CreateSensorCommand command = new CreateSensorCommand(userID);
        command.execute();
        
        return "OK";
    }
    
    @GET
    @Path("/updateSoilMoistureThreshold/{sensorID}/{value}")
    public String updateSoilThreshold(@PathParam("sensorID") int sensorID, @PathParam("value") int value)
    {
        Object user;
        user = CommandFactory
                .createCommand(
                        CommandFactory.UPDATESOILMOISTURETHRESHOLD, sensorID, value)
                .execute();
        
        return "OK";
    }
    
    @GET
    @Path("/updateAirMoistureThreshold/{sensorID}/{value}")
    public String updateAirThreshold(@PathParam("sensorID") int sensorID, @PathParam("value") int value)
    {
        Object user;
        user = CommandFactory
                .createCommand(
                        CommandFactory.UPDATEAIRMOISTURETHRESHOLD, sensorID, value)
                .execute();
        
        return "OK";
    }
    
    @GET
    @Path("/getSensorByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getSensorByID(@PathParam("id") int id) {
        ArrayList<UsersDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_SENSOR_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/getSensorByUserID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getSensorByUserID(@PathParam("id") int id) {
        ArrayList<UsersDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_SENSOR_BY_USERID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/getAllSensors")
    @Produces("application/json")
    @Consumes("application/json")
    public String getAllSensors() {
        ArrayList<SensorsDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ALL_SENSORS)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/GetAllAdminsCommand")
    @Produces("application/json")
    @Consumes("application/json")
    public String getAllAdmins() {
        ArrayList<AdminsDTO> getArray;

        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ALL_ADMINS)
                .execute();
        Gson gson = new Gson();
        String theString = gson.toJson(getArray);

        return theString;
    }
    
    @GET
    @Path("/getAdminByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getAdminByID(@PathParam("id") int id) {
        ArrayList<AdminsDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ADMIN_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/createAdmin/{username}/{password}")
    public String createAdmin(@PathParam("username") String email, @PathParam("password") String password)
    {
        CreateAdminCommand command = new CreateAdminCommand(email, password);
        command.execute();
        
        return "OK";
    }
    
    @GET
    @Path("/GetAllReadingsCommand")
    @Produces("application/json")
    @Consumes("application/json")
    public String getAllReadings() {
        ArrayList<UsersDTO> getArray;

        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_ALL_READINGS)
                .execute();
        Gson gson = new Gson();
        String theString = gson.toJson(getArray);

        return theString;
    }
    
    @GET
    @Path("/getReadingByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getReadingByID(@PathParam("id") int id) {
        ArrayList<UsersDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_READING_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    @GET
    @Path("/getReadingsBySensorID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getReadingsBySensorID(@PathParam("id") int id) {
        ArrayList<UsersDTO> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_READINGS_BY_SENSORID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = gson.toJson(getArray);

        return jsonArray;
    }
    
    
    
    @GET
    @Path("/createReading/{sensorID}/{soil}/{air}/{watered}")
    public String createReading(
            @PathParam("sensorID") int sensorID, 
            @PathParam("soil") int soil, 
            @PathParam("air") int air, 
            @PathParam("watered") String watered
    )
    {
        CreateReadingCommand command = new CreateReadingCommand(sensorID, soil, air, watered);
        command.execute();
        
        return "OK";
    }
    
    @GET
    @Path("/getSensorAirHumidityByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getSensorAirHumidityByID(@PathParam("id") int id) {
        ArrayList<Integer> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_SENSOR_AIR_HUMIDITY_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = getArray.toString();
        jsonArray = jsonArray.substring(1, jsonArray.length()-1);
        return jsonArray;
    }
    
    @GET
    @Path("/getSensorSoilHumidityByID/{id}")
    @Produces("application/json")
    @Consumes("application/json")
    public String getSensorSoilHumidityByID(@PathParam("id") int id) {
        ArrayList<Integer> getArray;
        getArray = (ArrayList) CommandFactory
                .createCommand(
                        CommandFactory.GET_SENSOR_SOIL_HUMIDITY_BY_ID, id)
                .execute();
        Gson gson = new Gson();
        String jsonArray = getArray.toString();
        jsonArray = jsonArray.substring(1, jsonArray.length()-1);
        return jsonArray;
    }
    
    //TODO: GetAllSensorsCommand
    
    /**
     * PUT method for updating or creating an instance of MyResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
