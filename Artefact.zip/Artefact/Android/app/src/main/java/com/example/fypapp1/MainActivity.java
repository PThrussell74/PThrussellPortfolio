package com.example.fypapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity {

    private String localIP = "192.168.0.20";
    final String ENDPOINT = "http://"+localIP+":8080/ModuleServer/webresources/myPath/";

    TextView sampleText;
    Button logOut;
    Button mySensors;
    PersonDTO loadedPerson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sampleText = (TextView)findViewById(R.id.helloText);
        logOut = (Button)findViewById(R.id.reloadButton);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();

            }
        });

        mySensors = (Button)findViewById(R.id.viewMySensors);
        mySensors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferToMySensors();

            }
        });
        assemblePerson();
    }

    private void logout()
    {
        loadedPerson = new PersonDTO(-1, "null", "null");
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    private void assemblePerson()
    {
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            loadedPerson= null;
            sampleText.setText("Error: login not found.");
        }
        else
        {
            loadedPerson = new PersonDTO(extras.getInt("userID"), extras.getString("userEmail"), extras.getString("userPass"));
            loadedPerson.setAdmin(extras.getString("admin"));
            sampleText.setText(loadedPerson.getEmail()+": "+loadedPerson.getUserID());
        }
    }

    public void transferToMySensors()
    {
        Intent intent = new Intent(this, MySensorsActivity.class);
        intent.putExtra("userEmail", loadedPerson.getEmail());
        intent.putExtra("userPass", loadedPerson.getPassword());
        intent.putExtra("userID", loadedPerson.getUserID());
        intent.putExtra("admin", loadedPerson.getAdmin());
        startActivity(intent);
    }
}
