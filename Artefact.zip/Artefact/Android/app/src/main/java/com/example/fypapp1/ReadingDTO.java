package com.example.fypapp1;

import java.sql.Timestamp;
import java.util.Date;

public class ReadingDTO
{

    private final int readingID;
    private final int sensorID;
    private final Timestamp date;
    private final int soilMoisture;
    private final int airMoisture;
    private final String watered;

    public ReadingDTO(int readingID, int sensorID, Timestamp date, int soilMoisture, int airMoisture, String watered) {
        this.readingID = readingID;
        this.sensorID = sensorID;
        this.date = date;
        this.soilMoisture = soilMoisture;
        this.airMoisture = airMoisture;
        this.watered = watered;
    }

    public int getReadingID() {
        return readingID;
    }

    public int getSensorID() {
        return sensorID;
    }

    public Timestamp getDate() {
        return date;
    }

    public int getSoilMoisture() {
        return soilMoisture;
    }

    public int getAirMoisture() {
        return airMoisture;
    }

    public String getWatered() {
        return watered;
    }
}
