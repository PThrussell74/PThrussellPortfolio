package com.example.fypapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.JsonReader;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class LoginActivity extends AppCompatActivity {

    private RequestQueue requestQueue;
    private String localIP = "192.168.0.20";
    final String ENDPOINT = "http://"+localIP+":8080/ModuleServer/webresources/myPath/";
    final String testMessage = ENDPOINT.concat("GetTheTestMessage");
    private String getResult = "no Value";
    private Gson gson;
    private String adminStatus;


    private TextView serverStatus;
    private EditText email;
    private EditText password;
    private Button signIn;
    private Button register;
    private PersonDTO user2 = new PersonDTO(-1, "null", "null");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        serverStatus = (TextView)findViewById(R.id.serverStatus);
        attemptLoad();

        email = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);

        signIn = (Button)findViewById(R.id.login);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptSignIn();

            }
        });

        register = (Button)findViewById(R.id.createAccount);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptCreateAccount();

            }
        });
    }

    private void attemptCreateAccount()
    {
        user2 = new PersonDTO(-1, "null", "null");
        String em = email.getText().toString();
        String pw = password.getText().toString();
        String sendMessage = ENDPOINT + "checkUserExists/" + em + "/" + pw;
        Intent intent = getIntent();
        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();
        requestQueue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(Request.Method.GET, sendMessage, onAccountCreated, onError);
        requestQueue.add(req);
    }

    private void attemptSignIn()
    {
        user2 = new PersonDTO(-1, "null", "null");
        String em = email.getText().toString();
        String pw = password.getText().toString();
        String sendMessage = ENDPOINT + "loginUser/" + em + "/" + pw;
        adminStatus = "false";
        if (((Switch) findViewById(R.id.adminOff)).isChecked())
        {
            sendMessage = ENDPOINT + "loginAdmin/" + em + "/" + pw;
            adminStatus = "true";
        }
        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();
        requestQueue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(Request.Method.GET, sendMessage, onLoginLoaded, onError);
        requestQueue.add(req);

    }

    private void attemptLoad()
    {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();
        requestQueue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(Request.Method.GET, testMessage, onConnectLoaded, onError);
        requestQueue.add(req);
    }

    private final Response.Listener<String> onConnectLoaded = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            getResult = gson.fromJson(response, String.class);
            serverStatus.setText("Server Status: "+getResult);
        }
    };

    private final Response.Listener<String> onLoginLoaded = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            Gson gson = new Gson();
            PersonDTO user = gson.fromJson(response, PersonDTO.class);
            if (!user.getEmail().equals("null"))
            {
                user2.setEmail(user.getEmail());
                user2.setUserID(user.getUserID());
                if (adminStatus.equals("true"))
                {
                    transferToAdminMenu();
                }
                else
                {
                    transferToMainMenu();
                }

            }
            else
            {
                Toast.makeText(getApplicationContext(), "Incorrect credentials.", Toast.LENGTH_LONG).show();
            }
        }
    };

    private final Response.Listener<String> onAccountCreated = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            getResult = gson.fromJson(response, String.class);
            if (getResult.equals("exist"))
            {
                Toast.makeText(getApplicationContext(), "This email has already been used to create an account!", Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Your user account has been created! You can now login", Toast.LENGTH_LONG).show();
            }
        }
    };

    public void transferToMainMenu(){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("userEmail", user2.getEmail());
        intent.putExtra("userPass", user2.getPassword());
        intent.putExtra("userID", user2.getUserID());
        intent.putExtra("admin", adminStatus);
        startActivity(intent);
    }
    public void transferToAdminMenu(){
        Intent intent = new Intent(this, AdMainActivity.class);
        intent.putExtra("userEmail", user2.getEmail());
        intent.putExtra("userPass", user2.getPassword());
        intent.putExtra("userID", user2.getUserID());
        intent.putExtra("admin", adminStatus);
        startActivity(intent);
    }

    private final Response.ErrorListener onError = new Response.ErrorListener()
    {
        @Override
        public void onErrorResponse(VolleyError error)
        {
            Toast.makeText(getApplicationContext(), "My Error: "+error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };
}
