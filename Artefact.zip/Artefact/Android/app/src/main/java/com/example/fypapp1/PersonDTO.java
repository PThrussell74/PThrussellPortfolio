package com.example.fypapp1;

public class PersonDTO {

    private int userID;
    private String email;
    private String password;
    private String isAdmin;

    public PersonDTO(int userID, String email, String password) {
        this.userID = userID;
        this.email = email;
        this.password = password;
    }

    public PersonDTO(int userID, String email, String password, String isAdmin) {
        this.userID = userID;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public String getAdmin() {
        return isAdmin;
    }

    public void setAdmin(String admin) {
        isAdmin = admin;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUserID() {
        return userID;
    }

    public String getEmail() {
        return email;
    }

    public boolean matchingPassword(String input)
    {
        return password.equals(input);
    }

    @Override
    public String toString() {
        return userID+" - "+email+" "+password;
    }
}
