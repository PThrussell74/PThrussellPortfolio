package com.example.fypapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MySensorsActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private RequestQueue requestQueue;
    private String localIP = "192.168.0.20";
    final String ENDPOINT = "http://"+localIP+":8080/ModuleServer/webresources/myPath/";
    Gson gson;
    private PersonDTO loadedPerson;

    List<SensorDTO> sensorList;
    private ListView listForSensors;

    TextView sampleText;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sensors);
        sampleText = (TextView)findViewById(R.id.helloText);
        listForSensors = (ListView)findViewById(R.id.viewBooks);
        listForSensors.setOnItemClickListener((AdapterView.OnItemClickListener) this);

        back = (Button)findViewById(R.id.backButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferToMenu();

            }
        });

        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();
        requestQueue = Volley.newRequestQueue(this);
        assemblePerson();
        getMySensors();
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int posn, long ID)
    {
        if (loadedPerson.getAdmin().equals("false"))
        {
            Intent intent = new Intent(this, OneSensorActivity.class);
            intent.putExtra("sensorID", sensorList.get(posn).getSensorID());
            intent.putExtra("soilThreshold", sensorList.get(posn).getSoilHumidThreshold());
            intent.putExtra("airThreshold", sensorList.get(posn).getAirHumidThreshold());
            intent.putExtra("userEmail", loadedPerson.getEmail());
            intent.putExtra("userPass", loadedPerson.getPassword());
            intent.putExtra("userID", loadedPerson.getUserID());
            intent.putExtra("admin", loadedPerson.getAdmin());
            startActivity(intent);
        }

    }

    private void assemblePerson()
    {
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            loadedPerson= null;
            sampleText.setText("Error: login not found.");
        }
        else
        {
            loadedPerson = new PersonDTO(extras.getInt("userID"), extras.getString("userEmail"), extras.getString("userPass"));
            loadedPerson.setAdmin(extras.getString("admin"));
            sampleText.setText(loadedPerson.getEmail()+": "+loadedPerson.getUserID());
        }
    }



    private void getMySensors()
    {StringRequest req;
        if (loadedPerson.getAdmin().equals("true"))
        {
            req = new StringRequest(Request.Method.GET, ENDPOINT+"getAllSensors", onDetailsLoaded, onAdminDetailsError);
        }
        else
        {
            req = new StringRequest(Request.Method.GET, ENDPOINT+"getSensorByUserID/"+loadedPerson.getUserID(), onDetailsLoaded, onDetailsError);
        }
        requestQueue.add(req);
    }

    private final Response.Listener<String> onDetailsLoaded = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            sensorList = Arrays.asList(gson.fromJson(response, SensorDTO[].class));
            String[] sensorsForList = new String[sensorList.size()];
            for(int i = 0; i< sensorList.size(); i++)
            {
                String id = sensorList.get(i).getSensorID()+"";
                String soilThre = sensorList.get(i).getSoilHumidThreshold()+"";
                String AirThre = sensorList.get(i).getAirHumidThreshold()+"";
                sensorsForList[i] = "ID: "+id+" - S.Threshold: "+ soilThre +" - A.Threshold: "+ AirThre;
            }
            listForSensors.setAdapter(new ArrayAdapter(getApplicationContext(), R.layout.list_item, sensorsForList));
        }
    };

    private final Response.ErrorListener onDetailsError = new Response.ErrorListener()
    {
        @Override
        public void onErrorResponse(VolleyError error)
        {
            Toast.makeText(getApplicationContext(),"My Error: "+ error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    private final Response.ErrorListener onAdminDetailsError = new Response.ErrorListener()
    {
        @Override
        public void onErrorResponse(VolleyError error)
        {
            Toast.makeText(getApplicationContext(),"My Admin Error: "+ error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    public void transferToMenu(){
        Intent intent = new Intent(this, MainActivity.class);
        if (loadedPerson.getAdmin().equals("true"))
        {
            intent = new Intent(this, AdMainActivity.class);
        }
        intent.putExtra("userEmail", loadedPerson.getEmail());
        intent.putExtra("userPass", loadedPerson.getPassword());
        intent.putExtra("userID", loadedPerson.getUserID());
        intent.putExtra("admin", loadedPerson.getAdmin());
        startActivity(intent);
    }
}
