package com.example.fypapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Arrays;
import java.util.List;

public class OneSensorActivity extends AppCompatActivity {

    private RequestQueue requestQueue;
    private String localIP = "192.168.0.20";
    final String ENDPOINT = "http://"+localIP+":8080/ModuleServer/webresources/myPath/";
    Gson gson;
    private PersonDTO loadedPerson;

    List<ReadingDTO> sensorList;
    private ListView listForSensors;
    private int sensorID = 0;

    TextView sampleText;
    TextView helloText;
    TextView sensorName;

    private EditText soilValue;
    private EditText airValue;

    Button back;
    Button acceptSoil;
    Button acceptAir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_sensor);

        soilValue = (EditText)findViewById(R.id.changeSThreshold);
        //airValue = (EditText)findViewById(R.id.changeHThreshold);

        back = (Button)findViewById(R.id.backButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferToMenu();

            }
        });

        acceptSoil = (Button)findViewById(R.id.soilChange);
        acceptSoil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSoil();

            }
        });

        //acceptAir = (Button)findViewById(R.id.humidChange);

        sampleText = (TextView)findViewById(R.id.sensorInfo);
        helloText = (TextView)findViewById(R.id.helloText);
        sensorName = (TextView)findViewById(R.id.sensorName);
        listForSensors = (ListView)findViewById(R.id.viewBooks2);

        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.setDateFormat("MMM DD, yyyy HH:mm:ss").create();
        requestQueue = Volley.newRequestQueue(this);

        assembleSensor();
        assemblePerson();
        getMyReadings();
    }

    private void getMyReadings()
    {
        String getMine = ENDPOINT+"getReadingsBySensorID/"+sensorID;
        StringRequest req = new StringRequest(Request.Method.GET, getMine, onDetailsLoaded, onDetailsError);
        requestQueue.add(req);
    }

    private void changeSoil() {
        try
    {
            int receivedValue = Integer.parseInt(soilValue.getText().toString());
            if (receivedValue>100 || receivedValue<1)
            {Toast.makeText(getApplicationContext(),"Text Error. Please enter an integer between 1 and 100.", Toast.LENGTH_LONG).show();}
            else
            {
                StringRequest req = new StringRequest(Request.Method.GET, ENDPOINT+"updateSoilMoistureThreshold/"+sensorID+"/"+receivedValue, onSuccessfulChange, onDetailsError);
                requestQueue.add(req);
            }
        }catch (Exception e)
        {Toast.makeText(getApplicationContext(),"Text Error. Please enter an integer between 1 and 100.", Toast.LENGTH_LONG).show();}
    }

    private void changeAir()
    {try
        {
            int receivedValue = Integer.parseInt(airValue.getText().toString());
            if (receivedValue>100 || receivedValue<1)
            {Toast.makeText(getApplicationContext(),"Text Error. Please enter an integer between 1 and 100.", Toast.LENGTH_LONG).show();}
            else
            {
                StringRequest req = new StringRequest(Request.Method.GET, ENDPOINT+"updateAirMoistureThreshold/"+sensorID+"/"+receivedValue, onSuccessfulChange, onDetailsError);
                requestQueue.add(req);
            }
        }catch (Exception e)
        {Toast.makeText(getApplicationContext(),"Text Error. Please enter an integer between 1 and 100.", Toast.LENGTH_LONG).show();}

        //Toast.makeText(getApplicationContext(),"req: "+ req, Toast.LENGTH_LONG).show();

    }

    private final Response.Listener<String> onSuccessfulChange = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            Toast.makeText(getApplicationContext(),"Information updated! The next time the Arduino connects to the server its values will change.", Toast.LENGTH_LONG).show();
            sampleText.setText("Re-load to view changes");
        }
    };

    private final Response.Listener<String> onDetailsLoaded = new Response.Listener<String>()
    {
        @Override
        public void onResponse(String response)
        {
            sensorList = Arrays.asList(gson.fromJson(response, ReadingDTO[].class));
            String[] sensorsForList = new String[sensorList.size()];
            for(int i = 0; i< sensorList.size(); i++)
            {
                String soilM = sensorList.get(i).getSoilMoisture()+"";
                String airM = sensorList.get(i).getAirMoisture()+"";
                String date = sensorList.get(i).getDate()+"";
                String watered = sensorList.get(i).getWatered()+"";
                sensorsForList[i] = date+"\nSoil: "+ soilM +"% - Air: "+ airM+"%\nWatered: "+ watered;
            }
            listForSensors.setAdapter(new ArrayAdapter(getApplicationContext(), R.layout.list_item, sensorsForList));

        }
    };

    private final Response.ErrorListener onDetailsError = new Response.ErrorListener()
    {
        @Override
        public void onErrorResponse(VolleyError error)
        {
            Toast.makeText(getApplicationContext(),"My Error: "+ error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    private void assembleSensor()
    {
        Bundle extras = getIntent().getExtras();
        if(extras == null)
        {
            sensorName.setText("No sensor found");
        }
        else
        {
            sensorID = extras.getInt("sensorID");
            sensorName.setText("Sensor ID: "+sensorID);
            sampleText.setText("Air humidity Threshold: "+extras.get(("airThreshold"))+"\nSoil humidity Threshold: "+extras.get("soilThreshold"));
        }


    }

    private void assemblePerson()
    {
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            loadedPerson= null;
            helloText.setText("Error: login not found.");
        }
        else
        {
            loadedPerson = new PersonDTO(extras.getInt("userID"), extras.getString("userEmail"), extras.getString("userPass"));
            loadedPerson.setAdmin(extras.getString("admin"));
            helloText.setText(loadedPerson.getEmail()+": "+loadedPerson.getUserID());
        }
    }

    public void transferToMenu()
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("userEmail", loadedPerson.getEmail());
        intent.putExtra("userPass", loadedPerson.getPassword());
        intent.putExtra("userID", loadedPerson.getUserID());
        intent.putExtra("admin", loadedPerson.getAdmin());
        startActivity(intent);
    }
}
